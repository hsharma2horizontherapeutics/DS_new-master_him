import pandas as pd
from .GraphController import GraphController
import networkx as nx


class TEPROBuilder:

    def __init__(self):
        # variables

        self.input_dir = 'L:\\TEPRO\\LRx\\output\\masterCodes_v1\\referrals_v2\\'
        self.claims_pkl = 'claims_refs.pkl'
        self.claims_hcps_pkl = 'refs_hcps.pkl'
        self.weight_cutoff = 2
        self.claims_output = None
        self.controller = None
        self.hcps = None

    def create_graph(self, conn, veeva):

        controller = GraphController(conn)

        # RUN tepro_lrx_hcp_referral_data on spark server first to output
        # read in raw referrals from claims and the HCP data from the claims
        claims_df = pd.read_pickle(self.input_dir + self.claims_pkl)

        claims_output = claims_df[['patient_id', 'NPI', 'prev_NPI']].drop_duplicates()
        claims_output['weight'] = 1

        claims_output = claims_output.groupby(['prev_NPI', 'NPI'])[['weight']].sum()
        claims_output = claims_output[claims_output['weight'] > self.weight_cutoff].reset_index()
        claims_output['src_claims'] = 1

        # get referrals from veeva
        veeva_refs = veeva.get_referrals()
        veeva_refs['src_veeva'] = 1

        # add referrals to graph
        controller.add_data(claims_output, data_type='edges',
                            node_ids=['prev_NPI', 'NPI'], attrib_cols=['weight', 'src_claims'])

        controller.add_data(veeva_refs, data_type='edges',
                            node_ids=['prev_NPI', 'NPI'], attrib_cols=['src_veeva'])

        # calc institutional overlap
        controller.calc_institution_overlaps(conn)

        # once data is added, calc HCP graph fields (connectedness measures)
        controller.calc_hcp_stats()

        self.claims_output = claims_output
        self.controller = controller

        self.find_tepro_hcps(veeva=veeva)
        self.calc_hcp_segment()
        self.clear_isolates()
        self.format_nodes()
        self.controller.calc_subgraphs()

    # find the HCPs and add the HCP fields to the nodes
    def find_tepro_hcps(self, veeva):

        if self.claims_output is None:
            raise ValueError('Must build claims output first')

        # build HCP table (needed for attributes)
        veeva_hcps = veeva.get_hcps()
        veeva_hcps = veeva_hcps[
            ['NPI_vod__c', 'FirstName', 'LastName', 'HZN_Group__c', 'HZN_TEP_Target_Score__c', 'terr']]
        veeva_hcps.columns = ['NPI', 'first_name', 'last_name', 'specialty', 'target_score', 'terr']
        veeva_hcps['source'] = 'veeva'

        claims_hcps = pd.read_pickle(self.input_dir + self.claims_hcps_pkl)

        claims_hcps = claims_hcps[['NPI', 'FIRST_NM', 'LAST_NM', 'hcp_spec']]
        claims_hcps.columns = ['NPI', 'first_name', 'last_name', 'specialty']
        claims_hcps['source'] = 'claims'

        # only keep claims hcps if they are in the referral graph
        referral_hcps = pd.DataFrame([x for x in self.controller.G.nodes], columns=['NPI'])
        claims_hcps = pd.merge(claims_hcps, referral_hcps, how='inner', on=['NPI'])

        hcp_all = pd.concat([veeva_hcps, claims_hcps])

        # clean specialty
        hcp_all.loc[hcp_all['specialty'] == 'OPHTHALMOLOGY', 'specialty'] = 'OPTHO'
        hcp_all.loc[hcp_all['specialty'] == 'ENDOCRINOLOGY', 'specialty'] = 'ENDO'
        hcp_all['first_name'] = hcp_all['first_name'].str.upper()
        hcp_all['last_name'] = hcp_all['last_name'].str.upper()

        # clean target score and terr
        hcp_all.loc[hcp_all['target_score'].isnull(), 'target_score'] = 'No Score'
        hcp_all.loc[hcp_all['terr'].isnull(), 'terr'] = 'No Terr'

        hcp_out = hcp_all[(hcp_all['source'] == 'veeva') | (~hcp_all['NPI'].isin(veeva_hcps['NPI']))]

        hcp_out.drop(['source'], axis=1, inplace=True)

        self.hcps = hcp_out
        self.controller.add_data(hcp_out, data_type='nodes', node_ids=['NPI'],
                                 attrib_cols=['first_name', 'last_name', 'specialty', 'target_score', 'terr'])

        # add on primary institution
        query = """select """

    # calc HCP (node) fields
    def calc_hcp_segment(self, coi_cutoff=5, link_cutoff=3):
        for node in self.controller.G.nodes(data=True):
            if 'page_rank' not in node[1]:
                self.controller.G.nodes[node[0]]['ref_seg'] = 'veeva_add'
            elif node[1]['in_hcps'] >= coi_cutoff:
                self.controller.G.nodes[node[0]]['ref_seg'] = 'CoI'
            elif node[1]['connected_hcps'] > link_cutoff:
                self.controller.G.nodes[node[0]]['ref_seg'] = 'Med Conn'
            else:
                self.controller.G.nodes[node[0]]['ref_seg'] = 'low Conn'

    def clear_isolates(self):
        self.controller.G.remove_nodes_from(list(nx.isolates(self.controller.G)))

    # add HCP fields needed for correct formatting
    def format_nodes(self):

        for node in self.controller.G.nodes(data=True):
            node_id = node[0]
            node_dict = node[1]
            # set label
            self.controller.G.nodes[node_id]['label'] = node_dict['first_name'] + '&#92;n' \
                                    + node_dict['last_name'] \
                                    + '&#92;n' + str(node_dict['target_score']) + ', ' + node_dict['ref_seg']


            # fill colors
            if node_dict['specialty'] == 'OPTHO' and node_dict['ref_seg'] == 'CoI':
                self.controller.G.nodes[node_id]['fillcolor'] = '#4076BA'
            elif node_dict['specialty'] == 'OPTHO':
                self.controller.G.nodes[node_id]['fillcolor'] = '#8BADD7'
            if node_dict['specialty'] == 'ENDO' and node_dict['ref_seg'] == 'CoI':
                self.controller.G.nodes[node_id]['fillcolor'] = '#E3CACE'
            elif node_dict['specialty'] == 'ENDO':
                self.controller.G.nodes[node_id]['fillcolor'] = '#D1A7AD'

        # formatting attributes for nodes
        formatting_attrs = {}
        for x in self.controller.G.nodes:
            formatting_attrs[x] = {'fontsize': 14, 'fontname': 'Calibri', 'style': 'filled'}
        nx.set_node_attributes(self.controller.G, formatting_attrs)

        # set edge formatting
        for x in self.controller.G.edges(data=True):
            self.controller.G[x[0]][x[1]]['label'] = \
                self.controller.G[x[0]][x[1]]['weight'] if 'weight' in self.controller.G[x[0]][x[1]] else 'Veeva'
            self.controller.G[x[0]][x[1]]['fontsize'] = 14
            self.controller.G[x[0]][x[1]]['fontname'] = 'Calibri'
            self.controller.G[x[0]][x[1]]['penwidth'] = 3 if 'same_inst' in self.controller.G[x[0]][x[1]] else 1
            self.controller.G[x[0]][x[1]]['color'] = '#c00000' if 'same_inst' in self.controller.G[x[0]][x[1]] else '#40474e'


            # TODO format edge if they are in the same institution[color = blue, penwidth = 5]
