import pandas as pd
from .GraphController import GraphController
from .helper_functions import connect

input_dir = 'L:\\TEPRO\\LRx\\output\\masterCodes_v1\\referrals_v2\\'
claims_pkl = 'claims_refs.pkl'
weight_cutoff = 2

conn = connect(db='ATLAS', server='USLSACASQL1')

query = """select distinct account_id, value from [account_attribs] where attrib_id in ( 2,10)"""
attrib_df = pd.read_sql(query, conn)

query = """select hcp_npi, account_id
from hcp_affiliations
where is_active = 1 and is_primary = 1 and account_id is not null"""
accounts_df = pd.read_sql(query, conn)
account_dict = accounts_df.set_index(['hcp_npi'])['account_id'].to_dict()

claims_df = pd.read_pickle(input_dir + claims_pkl)

claims_output = claims_df[['patient_id', 'NPI', 'prev_NPI']].drop_duplicates()
claims_output['weight'] = 1

claims_output['prev_account_id'] = claims_output['prev_NPI'].map(account_dict)
claims_output['account_id'] = claims_output['NPI'].map(account_dict)

claims_output.drop(['prev_NPI', 'NPI'], axis=1, inplace=True)
claims_output = claims_output[(claims_output['account'].notnull()) & (claims_output['prev_account'].notnull())]

claims_output = claims_output.groupby(['prev_account', 'account'])[['weight']].sum()
claims_output = claims_output[claims_output['weight'] > weight_cutoff].reset_index()

claims_output['src_claims'] = 1

controller = GraphController(conn)

controller.add_data(claims_output, data_type='edges',
                    node_ids=['prev_account', 'account'], attrib_cols=['weight', 'src_claims'])

