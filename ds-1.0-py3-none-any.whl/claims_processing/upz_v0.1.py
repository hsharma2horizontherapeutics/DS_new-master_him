import warnings
import pandas as pd
import numpy as np
import ds.helper_functions as hf

warnings.filterwarnings('ignore')
pd.set_option('display.max_rows', 500)
pd.set_option('display.max_columns', 500)
pd.set_option('display.width', 1000)

def preprocess(upz_claim):
    upz_claim['svc_date']=pd.to_datetime(upz_claim['svc_date'])
    upz_claim['nmosd_dx_date']=pd.to_datetime(upz_claim['nmosd_dx_date'])

    # indicator
    upz_claim['rituximab_ind']=np.where(upz_claim['code_group2'].isin(['rituximab']), 1, 0)
    upz_claim['upz_ind']=np.where(upz_claim['code_group2'].isin(['upz']), 1, 0)
    upz_claim['soliris_ind']=np.where(upz_claim['code_group2'].isin(['soliris']), 1, 0)
    upz_claim['enspryng_ind']=np.where(upz_claim['code_group2'].isin(['enspryng']), 1, 0)
    
    ## Adding it for other drugs...
    upz_claim['truxima_ind']=np.where(upz_claim['code'].isin(['Q5115']), 1, 0)
    upz_claim['ruxience_ind']=np.where(upz_claim['code'].isin(['Q5119']), 1, 0)
    upz_claim['riabni_ind']=np.where(upz_claim['code'].isin(['Q5123']), 1, 0)
    
    
    upz_claim['ist_ind']=np.where(upz_claim['code_group2'].isin(['mycophenolate_mofetil','azathioprine']), 1, 0)
    upz_claim['nmosd_ind']=np.where(upz_claim['code_group2'].isin(['nmosd']), 1, 0)
        
    return upz_claim

# sum on 6 month time window

def sum_6month(upz_claim, start_date):
    upz_claim['start_date']=start_date
    upz_claim['start_date']=pd.to_datetime(upz_claim['start_date'])
    upz_claim['end_date']=upz_claim['start_date'] + pd.DateOffset (months=6) - pd.DateOffset(days=1)
    
    nmosd_6mnth=upz_claim[(upz_claim['svc_date']>=upz_claim['start_date'])&(upz_claim['svc_date']<=upz_claim['end_date'])]
    nmosd_biologic=nmosd_6mnth[(nmosd_6mnth['rituximab_ind']==1)|(nmosd_6mnth['upz_ind']==1)|(nmosd_6mnth['soliris_ind']==1)|(nmosd_6mnth['enspryng_ind']==1)|(nmosd_6mnth['ist_ind']==1) | (nmosd_6mnth['truxima_ind']==1) | 
                               (nmosd_6mnth['ruxience_ind']==1) | (nmosd_6mnth['riabni_ind']==1)]\
                            [['patient_id','svc_date','code','code_group2','rituximab_ind','upz_ind','soliris_ind','enspryng_ind','ist_ind','truxima_ind','ruxience_ind','riabni_ind']].drop_duplicates()

    # groupby patient level based on biologic/ist indicator
    claim_sum=nmosd_biologic.groupby('patient_id').agg({'rituximab_ind':'sum','upz_ind': 'sum','soliris_ind': 'sum','enspryng_ind':'sum','ist_ind':'sum','truxima_ind':'sum','ruxience_ind':'sum','riabni_ind':'sum'}).reset_index()
    
    # get the most recent biologic treatment
    # If on 2 biologics in past 6 months, allocate the patient to most recent biologic
    # If on IST and no biologic in past 6 months, allocate to IST monotherapy
    nmosd_biologic_recent=nmosd_6mnth[(nmosd_6mnth['rituximab_ind']==1)|(nmosd_6mnth['upz_ind']==1)|(nmosd_6mnth['soliris_ind']==1)|(nmosd_6mnth['enspryng_ind']==1) | (nmosd_6mnth['truxima_ind']==1) | (nmosd_6mnth['ruxience_ind']==1) | (nmosd_6mnth['riabni_ind']==1) ]\
                                     .sort_values(['patient_id', 'svc_date']).drop_duplicates(subset='patient_id', keep='last')
    nmosd_biologic_recent.loc[nmosd_biologic_recent['rituximab_ind']==1, 'Unique Pt with NMOSD Dx on a Maintenance Therapy']='RTX monotherapy or in combo with IST'
    nmosd_biologic_recent.loc[nmosd_biologic_recent['upz_ind']==1, 'Unique Pt with NMOSD Dx on a Maintenance Therapy']='UPLIZNA monotherapy or in combo with IST'
    nmosd_biologic_recent.loc[nmosd_biologic_recent['soliris_ind']==1, 'Unique Pt with NMOSD Dx on a Maintenance Therapy']='SOLIRIS monotherapy or in combo with IST'
    nmosd_biologic_recent.loc[nmosd_biologic_recent['enspryng_ind']==1, 'Unique Pt with NMOSD Dx on a Maintenance Therapy']='ENSPRYNG monotherapy or in combo with IST'
    
    nmosd_biologic_recent.loc[nmosd_biologic_recent['truxima_ind']==1, 'Unique Pt with NMOSD Dx on a Maintenance Therapy']='TRUXIMA monotherapy or in combo with IST'
    nmosd_biologic_recent.loc[nmosd_biologic_recent['ruxience_ind']==1, 'Unique Pt with NMOSD Dx on a Maintenance Therapy']='RUXIENCE monotherapy or in combo with IST'
    nmosd_biologic_recent.loc[nmosd_biologic_recent['riabni_ind']==1, 'Unique Pt with NMOSD Dx on a Maintenance Therapy']='RIABNI monotherapy or in combo with IST'
    
    nmosd_biologic_pat=nmosd_biologic_recent[['patient_id','Unique Pt with NMOSD Dx on a Maintenance Therapy']].drop_duplicates()
    
    # separate biologic with or wo ist
    bio_pat=claim_sum.merge(nmosd_biologic_pat, on='patient_id', how='left').drop_duplicates()
    bio_pat.loc[bio_pat['Unique Pt with NMOSD Dx on a Maintenance Therapy'].isnull(), 'Unique Pt with NMOSD Dx on a Maintenance Therapy']='IST Alone'
    bio_pat.fillna(0, inplace=True)
    bio_pat.loc[(bio_pat['Unique Pt with NMOSD Dx on a Maintenance Therapy']=='RTX monotherapy or in combo with IST')&(bio_pat['ist_ind']>0), 'pat_type']='RTX + IST'
    bio_pat.loc[(bio_pat['Unique Pt with NMOSD Dx on a Maintenance Therapy']=='RTX monotherapy or in combo with IST')&(bio_pat['ist_ind']==0), 'pat_type']='RTX alone'
    bio_pat.loc[(bio_pat['Unique Pt with NMOSD Dx on a Maintenance Therapy']=='UPLIZNA monotherapy or in combo with IST')&(bio_pat['ist_ind']>0), 'pat_type']='UPLIZNA + IST'
    bio_pat.loc[(bio_pat['Unique Pt with NMOSD Dx on a Maintenance Therapy']=='UPLIZNA monotherapy or in combo with IST')&(bio_pat['ist_ind']==0), 'pat_type']='UPLIZNA alone'
    bio_pat.loc[(bio_pat['Unique Pt with NMOSD Dx on a Maintenance Therapy']=='SOLIRIS monotherapy or in combo with IST')&(bio_pat['ist_ind']>0), 'pat_type']='SOLIRIS + IST'
    bio_pat.loc[(bio_pat['Unique Pt with NMOSD Dx on a Maintenance Therapy']=='SOLIRIS monotherapy or in combo with IST')&(bio_pat['ist_ind']==0), 'pat_type']='SOLIRIS alone'
    bio_pat.loc[(bio_pat['Unique Pt with NMOSD Dx on a Maintenance Therapy']=='ENSPRYNG monotherapy or in combo with IST')&(bio_pat['ist_ind']>0),'pat_type']='ENSPRYNG + IST'
    bio_pat.loc[(bio_pat['Unique Pt with NMOSD Dx on a Maintenance Therapy']=='ENSPRYNG monotherapy or in combo with IST')&(bio_pat['ist_ind']==0),'pat_type']='ENSPRYNG alone'
    
    bio_pat.loc[(bio_pat['Unique Pt with NMOSD Dx on a Maintenance Therapy']=='TRUXIMA monotherapy or in combo with IST')&(bio_pat['ist_ind']>0),'pat_type']='TRUXIMA + IST'
    bio_pat.loc[(bio_pat['Unique Pt with NMOSD Dx on a Maintenance Therapy']=='TRUXIMA monotherapy or in combo with IST')&(bio_pat['ist_ind']==0),'pat_type']='TRUXIMA alone'
    
    bio_pat.loc[(bio_pat['Unique Pt with NMOSD Dx on a Maintenance Therapy']=='RUXIENCE monotherapy or in combo with IST')&(bio_pat['ist_ind']>0),'pat_type']='RUXIENCE + IST'
    bio_pat.loc[(bio_pat['Unique Pt with NMOSD Dx on a Maintenance Therapy']=='RUXIENCE monotherapy or in combo with IST')&(bio_pat['ist_ind']==0),'pat_type']='RUXIENCE alone'
    
    bio_pat.loc[(bio_pat['Unique Pt with NMOSD Dx on a Maintenance Therapy']=='RIABNI monotherapy or in combo with IST')&(bio_pat['ist_ind']>0),'pat_type']='RIABNI + IST'
    bio_pat.loc[(bio_pat['Unique Pt with NMOSD Dx on a Maintenance Therapy']=='RIABNI monotherapy or in combo with IST')&(bio_pat['ist_ind']==0),'pat_type']='RIABNI alone'
    
    
    bio_pat.loc[(bio_pat['Unique Pt with NMOSD Dx on a Maintenance Therapy']=='IST Alone') & (bio_pat['ist_ind']>0),'pat_type']='IST alone'
    
    # summary on treatment type
    bio_pat_sum=bio_pat.groupby(['pat_type'])['patient_id'].nunique().reset_index()
    time_begin=str(upz_claim['start_date'].unique().astype('datetime64[D]')[0])
    time_end=str(upz_claim['end_date'].unique().astype('datetime64[D]')[0])
    bio_pat_sum['Time Window']=time_begin + ' to ' + time_end
    
    # reshape data
    bio_pat_sum1=bio_pat_sum.pivot(index='Time Window', columns='pat_type', values='patient_id')
    bio_pat_sum1=bio_pat_sum1.reset_index().rename_axis(None, axis=1)

    column_order = ['Time Window','UPLIZNA + IST','UPLIZNA alone', 'RTX + IST','RTX alone', 'SOLIRIS + IST','SOLIRIS alone', 'ENSPRYNG + IST','ENSPRYNG alone','TRUXIMA + IST','TRUXIMA alone','RUXIENCE + IST','RUXIENCE alone','RIABNI + IST','RIABNI alone','IST alone']
    for x in column_order:
        if x not in bio_pat_sum1.columns:
            bio_pat_sum1[x] = 0
    bio_pat_sum1=bio_pat_sum1[column_order]

    return bio_pat_sum1

def market_share(test=False):
    conn = hf.connect(server = 'USLSACASQL2',db = 'DS_Claims')
    upz_claim = """SELECT * FROM [DS_Claims].[dbo].[upz_nmosd_claims]"""
    upz_claim = pd.read_sql(upz_claim, conn)
    upz_claim=upz_claim[upz_claim['nmosd_dx_date'].notnull()]

    # preprocessing for indicator
    upz_claim=preprocess(upz_claim)

    # figure out time period
    svc_begin='2021-01-01'
    svc_end=str(upz_claim['svc_date'].max() - pd.DateOffset (months=5)).split(' ')[0]
    svc_period=pd.date_range(svc_begin, svc_end, freq='MS').strftime("%Y-%m-%d").tolist()

    # refresh 6 months from 2021-01-01 to most recent claims 
    biologic_sum=pd.DataFrame()

    for i in range(len(svc_period)):
        start_date=svc_period[i]
        trt_sum=sum_6month(upz_claim, start_date)
        biologic_sum=biologic_sum.append(trt_sum, ignore_index=True)
    
    if test:
        print(biologic_sum)
    else:
        biologic_sum.to_sql("upz_marketshare_refresh",con= hf.connect(server = 'USLSACASQL2',db = 'DS_Claims',engine=True),if_exists='replace', index=False)

def run():
    market_share()

if __name__=="__main__":
    run()



