import pyodbc
import sqlalchemy
import urllib


# connect to SQL server for stored procs
def connect(db='orp', engine=False, server='USLSACASQL2'):
    conn_str = 'DRIVER={SQL Server};SERVER=' + server + ';DATABASE=' + db + ';Trusted_Connection=yes'

    if engine:
        engine = sqlalchemy.create_engine(
            'mssql+pyodbc:///?odbc_connect=%s' % (
                urllib.parse.quote_plus(conn_str)))
        return engine
    # connect to SQL server for regular queries
    else:
        conn = pyodbc.connect(conn_str)
        return conn


# function to format datatypes - used for pandas push to_sql
# sample: df.to_sql(dest_tbl, conn, index = False, if_exists='replace',dtype = format_types(data_df))
def format_types(df):
    dtypedict = {}
    for i, j in zip(df.columns, df.dtypes):
        if "object" in str(j):
            dtypedict.update({i: sqlalchemy.types.NVARCHAR(length=255)})

        if "datetime" in str(j):
            dtypedict.update({i: sqlalchemy.types.DateTime()})

        if "float" in str(j):
            dtypedict.update({i: sqlalchemy.types.Float(precision=3, asdecimal=True)})

        if "int" in str(j):
            dtypedict.update({i: sqlalchemy.types.INT()})

        if "bool" in str(j):
            dtypedict.update({i: sqlalchemy.types.Boolean()})

        # if "Notes_MVN__c" in str(i) or 'Management_Note_MVN__c' in str(i) or 'Office_Contact_MVN__c' in str(
        #         i) or "Latest_Case_Note_MVN__c" in str(i):
        #     dtypedict.update({i: sqlalchemy.types.Text()})

    return dtypedict
