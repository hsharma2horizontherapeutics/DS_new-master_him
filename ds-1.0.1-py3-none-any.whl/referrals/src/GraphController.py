import pandas as pd
import networkx as nx


class GraphController:
    def __init__(self, conn):

        self.directed_graph = True
        self.subgraphs = None
        self.G = nx.DiGraph()

    # method for loading dataframe with pre-calculated fields. Bulk load
    def add_data(self, data, data_type='edges', node_ids=None, attrib_cols=None):

        if type(data) != pd.DataFrame:
            raise ValueError('add_data method currently only accepts dataframe')

        # format any attributes for inclusion and add
        if attrib_cols:
            attrib_dict = data[attrib_cols].to_dict(orient='records')

        if data_type == 'edges':
            if node_ids is None:
                node_ids = ['prev_NPI', 'NPI']
            else:
                if len(node_ids) != 2:
                    raise ValueError('exactly two node columns must be set for node_ids when loading edge data')
        elif data_type == 'nodes':
            if node_ids is None:
                node_ids = ['NPI']
            else:
                if len(node_ids) != 1:
                    raise ValueError('only one node column can be set for node_ids when loading node data')
        else:
            raise ValueError('Must add nodes or edges')

        # format records to list format of [from,to, {dict of attribs}]
        if data_type == 'edges' and attrib_cols:
            added_data = [(b[0], b[1], attrib_dict[a]) for a, b in enumerate(data[node_ids].values.tolist())]
            self.G.add_edges_from(added_data)
        elif data_type == 'nodes' and attrib_cols:
            added_data = [(b[0], attrib_dict[a]) for a, b in enumerate(data[node_ids].values.tolist())]
            self.G.add_nodes_from(added_data)
        elif data_type == 'edges':
            self.G.add_edges_from(data[node_ids].values.tolist())
        elif data_type == 'nodes':
            self.G.add_nodes_from(data[node_ids].values.tolist())

    # get the info for subgraphs and returns as df
    # noinspection PyAttributeOutsideInit
    def calc_subgraphs(self):
        # find subgraphs
        if self.directed_graph:
            self.subgraphs = [x for x in nx.weakly_connected_component_subgraphs(self.G)]
        else:
            self.subgraphs = [x for x in nx.connected_component_subgraphs(self.G)]

    # find the overlaps between the different institutions
    def calc_institution_overlaps(self, conn):

        query = """select account_id, hcp_npi from hcp_affiliations
                   where account_id is not null"""
        affil_df = pd.read_sql(query, conn)

        tepro_nodes = pd.DataFrame([x for x in self.G.nodes], columns=['hcp_npi'])

        affil_df = pd.merge(affil_df, tepro_nodes, how='inner', on=['hcp_npi'])

        inst_overlap_edges = []

        a = nx.Graph()
        a.add_edges_from(affil_df.values.tolist())

        # for every edge in graph, check whether they overlap and if so mark an attribute
        for x in self.G.edges():
            if a.has_node(x[0]) and a.has_node(x[1]):
                if nx.has_path(a, x[0], x[1]):
                    if nx.bidirectional_dijkstra(a, x[0], x[1])[0] == 2:
                        inst_overlap_edges.append([x[0], x[1]])

        # add it to edges as attribute
        inst_overlap_edges = pd.DataFrame(inst_overlap_edges, columns=['prev_NPI', 'NPI'])
        inst_overlap_edges['same_inst'] = 1
        self.add_data(inst_overlap_edges, data_type='edges', node_ids=None, attrib_cols=['same_inst'])

    # calc node fields
    def calc_hcp_stats(self):

        pagerank_dict = nx.pagerank(self.G, weight='weight', max_iter=1000)
        in_pats_dict = {x[0]: x[1] for x in self.G.in_degree(weight='weight')}
        in_hcps_dict = {x[0]: x[1] for x in self.G.in_degree()}
        out_pats_dict = {x[0]: x[1] for x in self.G.out_degree(weight='weight')}
        out_hcps_dict = {x[0]: x[1] for x in self.G.out_degree()}
        total_hcps_dict = {x[0]: x[1] for x in self.G.degree()}

        nx.set_node_attributes(self.G, pagerank_dict, 'page_rank')
        nx.set_node_attributes(self.G, in_pats_dict, 'in_pats')
        nx.set_node_attributes(self.G, out_pats_dict, 'out_pats')
        nx.set_node_attributes(self.G, in_hcps_dict, 'in_hcps')
        nx.set_node_attributes(self.G, out_hcps_dict, 'out_hcps')
        nx.set_node_attributes(self.G, total_hcps_dict, 'connected_hcps')

    def list_subgraphs(self):
        if self.subgraphs is None:
            self.calc_subgraphs()
        return pd.DataFrame([[x, len(y.nodes)] for x, y in enumerate(self.subgraphs)], columns=['clusterNo', 'nodes'])

    # return graph
    def get_graph(self):
        return self.G

    def get_subgraph(self, subgraph_id):
        return self.subgraphs[subgraph_id]

    # save graph to disk
    def save_graph(self, output_dir, file_name):
        nx.write_gpickle(self.G, output_dir + file_name + ".gpickle")

    # dataframe of nodes
    def edges_to_frame(self):
        raw_edges = [x for x in self.G.edges(data=True)]
        raw_edges = pd.DataFrame([x[2] for x in raw_edges], index=[(x[0], x[1]) for x in raw_edges]).reset_index()

        raw_edges[['from_node', 'to_node']] = pd.DataFrame(raw_edges['index'].tolist())
        raw_edges.drop(['index'], axis=1, inplace=True)
        return raw_edges

    # dataframe of nodes
    def nodes_to_frame(self):
        subgraph_dict = {}
        for x, y in enumerate(self.subgraphs):
            for z in y.nodes:
                subgraph_dict[z] = x

        raw_nodes = [x for x in self.G.nodes(data=True)]
        raw_nodes = pd.DataFrame([x[1] for x in raw_nodes], index=[x[0] for x in raw_nodes]).reset_index()
        raw_nodes.rename(columns={'index': 'node_id'}, inplace=True)
        raw_nodes['subgraph_id'] = raw_nodes['node_id'].map(subgraph_dict)

        return raw_nodes


