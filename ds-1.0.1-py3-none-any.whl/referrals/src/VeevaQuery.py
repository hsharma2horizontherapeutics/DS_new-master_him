import pandas as pd
import numpy as np
import warnings
warnings.filterwarnings('ignore')


class VeevaQuery:

    def __init__(self, conn, prod='tepro', input_query=None):
        self.prod = prod

        # pull from Tepro Veeva DB accounts if a custom query isn't provided
        if input_query:
            self.query = input_query
        else:
            if self.prod == 'tepro':
                self.query = """SELECT [Id], [LastName], [FirstName], [Specialty_1_vod__c], [Specialty_2_vod__c] 
                  ,[Gender_vod__c]
                  ,[NPI_vod__c], [HZN_ASOPRS_Member__c], [HZN_Assess_new_GO_TED_patients__c], [HZN_Attended_Ad_Board__c]
                  ,[HZN_Billing_reimbursement_process__c], [HZN_Determine_Severity_of_Patients_endo__c]
                  ,[HZN_Do_you_Buy_and_Bill_products_endo__c], [HZN_Do_you_Buy_and_Bill_products_oph__c]
                  ,[HZN_ECNU_Certification__c],[HZN_Early_intervention_in_treating_GO_TE__c]
                  ,[HZN_Early_intervention_in_treating_endo__c],[HZN_Formulary_New_Products__c],[HZN_Head_Pharmacist__c]
                  ,[HZN_Hospital_setting__c], [HZN_How_many_Graves_patients_per_year__c]
                  ,[HZN_How_many_Graves_patients_per_yr_endo__c]
                  ,[HZN_How_many_TED_patients_per_year_endo__c],[HZN_How_many_of_these_are_Active_endo__c]
                  ,[HZN_How_many_thyroid_patients_per_year__c],[HZN_How_you_manage_GO_TED_patients__c]
                  ,[HZN_How_you_manage_TED_patients_endo__c],[HZN_IV_Infusion_Location_endo__c],[HZN_IV_infusion_location__c]
                  ,[HZN_MBO_Accounts__c],[HZN_New_Products__c],[HZN_Nursing_In_service__c],[HZN_Oculoplastic_Surgeon__c]
                  ,[HZN_Office_Setting__c],[HZN_Oral_IV_steroid_length_of_use__c],[HZN_Oral_IV_steroid_length_of_use_endo__c]
                  ,[HZN_Other_Determination__c],[HZN_Other_Determination_endo__c],[HZN_Other_Endo__c],[HZN_Other_IV_Steroid_Rx__c]
                  ,[HZN_Other_IV_Steroid_Rx_endo__c],[HZN_Other_Setting_Endo__c],[HZN_Other_Setting__c],[HZN_Other_Treatments_Endo__c]
                  ,[HZN_Other_Treatments__c],[HZN_Other__c],[HZN_P_T_Committee_Endocrinologist__c],[HZN_P_T_Committee_label__c]
                  ,[HZN_P_T_committee_member__c],[HZN_Patient_materials_and_start_up_kits__c],[HZN_Primary_Decision_Makers__c]
                  ,[HZN_Primary_Endocrinology_Questions__c],[HZN_Prior_Authorization_Process__c]
                  ,[HZN_Referring_Endocrinologist__c],[HZN_Referring_Endocrinologist_lookup__c]
                  ,[HZN_Role_in_Hospital_Setting__c],[HZN_Secondary_Endocrinology_Questions__c]
                  ,[HZN_Secondary_Ophthalmology_Questions__c],[HZN_Severity_of_GO_TED_patients__c]
                  ,[HZN_Site_of_Care__c],[HZN_Sub_Specialty_Ophthalmology_TEP__c],[HZN_TED_social_emotional_impact__c]
                  ,[HZN_TED_social_emotional_impact_endo__c],[HZN_TEP_Other_Sub_Specialty__c],[HZN_TEP_Target_Score__c]
                  ,[HZN_Treatments_prescribed_for_TED_endo__c],[HZN_Trusted_Ophthalmologist_Endo__c]
                  ,[HZN_Trusted_co_managing_partner__c],[HZN_Trusted_co_managing_partner_lookup__c]
                  ,[HZN_What_is_your_office_based_practice__c],[HZN_What_is_your_office_based_type_endo__c]
                  ,[HZN_What_is_your_practice_type__c],[HZN_What_is_your_practice_type_endo__c]
                  ,[HZN_What_phase_do_you_refer_to__c],[HZN_Who_writes_IV_steroid_Rx__c]
                  ,[HZN_Who_writes_IV_steroid_Rx_endo__c],[HZN_influential_member_in_the_committee__c]
                  ,[HZN_of_TED_patients_diagnosed_endo__c],[Primary_Ophthalmology_Questions__c]
                  ,[Treatments_for_GO_TED_patients__c],[of_GO_TED_patients_diagnosed__c],[of_active_GO_TED_patients__c]
                  ,[HZN_Group__c],[HZN_Site_of_Care_Endo__c],[terr_id],[terr]
              FROM [veeva_ib_accounts]
              where IsDeleted = 0 and AccountType = 'Medical Professional'"""
            else:
                raise ValueError('product does not have a query setup to pull from Veeva')

        self.veeva_df = pd.read_sql(self.query, conn)

        self.veeva_df.loc[(self.veeva_df['HZN_Group__c'].isnull())
                          & (self.veeva_df['Specialty_1_vod__c'].str.upper()
                             .str.contains('ENDO')), 'HZN_Group__c'] = 'ENDO'

        self.veeva_df.loc[(self.veeva_df['HZN_Group__c'].isnull())
                          & (self.veeva_df['Specialty_1_vod__c'].str.upper()
                             .str.contains('OPHTH')), 'HZN_Group__c'] = 'OPTHO'

    # get the referrals listed in the veeva data - for other prods add to if statement
    def get_referrals(self):

        if self.prod == 'tepro':
            id_npi_dict = self.veeva_df.set_index(['Id'])['NPI_vod__c'].to_dict()

            veeva_survey_data = self.veeva_df[['Id', 'LastName', 'FirstName', 'NPI_vod__c', 'HZN_Group__c',
                                               'HZN_TEP_Target_Score__c', 'HZN_Trusted_Ophthalmologist_Endo__c',
                                               'HZN_Trusted_co_managing_partner__c', 'HZN_Oculoplastic_Surgeon__c',
                                               'HZN_Trusted_co_managing_partner_lookup__c',
                                               'HZN_Referring_Endocrinologist__c',
                                               'HZN_Referring_Endocrinologist_lookup__c']]

            veeva_survey_data = pd.melt(veeva_survey_data, id_vars=['Id', 'LastName', 'FirstName', 'NPI_vod__c',
                                                                    'HZN_Group__c', 'HZN_TEP_Target_Score__c'],
                                        var_name='survey_field', value_name='survey_value')

            veeva_survey_data = veeva_survey_data[
                (veeva_survey_data['survey_value'].notnull()) & (veeva_survey_data['survey_value'] != 'None')]

            # create reference IDs for directionality
            veeva_survey_data.loc[:, 'from'] = np.nan
            veeva_survey_data.loc[:, 'to'] = np.nan

            from_to_vars = ['HZN_Trusted_Ophthalmologist_Endo__c', 'HZN_Oculoplastic_Surgeon__c',
                            'HZN_Trusted_co_managing_partner_lookup__c', 'HZN_Trusted_co_managing_partner__c']
            to_from_vars = ['HZN_Referring_Endocrinologist_lookup__c']

            veeva_survey_data.loc[veeva_survey_data['survey_field'].isin(from_to_vars), ['from', 'to']] = \
                veeva_survey_data[veeva_survey_data['survey_field'].isin(from_to_vars)][['Id', 'survey_value']].values

            veeva_survey_data.loc[veeva_survey_data['survey_field'].isin(to_from_vars), ['from', 'to']] = \
                veeva_survey_data[veeva_survey_data['survey_field'].isin(to_from_vars)][['survey_value', 'Id']].values

            veeva_survey_data['from_npi'] = veeva_survey_data['from'].map(id_npi_dict)
            veeva_survey_data['to_npi'] = veeva_survey_data['to'].map(id_npi_dict)

            # filter out bad records
            veeva_survey_data = veeva_survey_data[
                (~veeva_survey_data['from_npi'].isnull()) & (~veeva_survey_data['to_npi'].isnull())]

            veeva_survey_data = veeva_survey_data[['to_npi', 'from_npi']]
            veeva_survey_data.columns = ['NPI', 'prev_NPI']

            return veeva_survey_data
        else:
            raise ValueError('product does not have a query setup to pull from Veeva')

    def get_hcps(self, fields=None):
        if fields is None:
            fields = ['LastName', 'FirstName', 'NPI_vod__c', 'HZN_Group__c',
                      'HZN_TEP_Target_Score__c', 'Specialty_1_vod__c', 'Specialty_2_vod__c', 'terr']
        return self.veeva_df[fields]
