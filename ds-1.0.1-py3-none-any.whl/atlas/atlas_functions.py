from keplergl import KeplerGl
import pandas as pd
import numpy as np
import pyodbc
from ds import helper_functions as hf
import geopandas as gp
import ds.mongo_apollo as mg
import datetime

import json
import networkx as nx
import networkx as nx
from networkx.algorithms import bipartite
from IPython.display import Image
from IPython.core.display import display, HTML

pd.options.display.float_format = '{:.1f}'.format
pd.set_option('display.max_colwidth', None)
atlas_conn = hf.connect(db = 'Atlas_Stage', server = 'USLSACASQL1')
geolocation_conn = hf.connect(db = 'Geolocation', server = 'USLSACASQL1')

#affiliated HCPs
query = """SELECT distinct account_id, hcp_npi
  FROM [Atlas_Stage].[dbo].[HCP_Affiliations]"""
hcp_affils = pd.read_sql(query,atlas_conn)
hcp_affils = hcp_affils.groupby(['account_id']).count().reset_index().rename(columns = {'hcp_npi':'affil_hcps'})

def _process_quarantine(conn=atlas_conn):
    #only do this every so often so there's time for all records to complete

    push_process = """EXEC hzn_atlas_process_quarantine"""
    ret = conn.execute(push_process)
    conn.commit()


def get_account_history(account_id,conn=atlas_conn):
    query = """SELECT * 
                FROM dbo.source_accounts_journey AS saj 
                WHERE saj.account_id = '{0}'""".format(account_id)
    return pd.read_sql(query,conn)

def _change_accounts(from_ids, into_id, username, change_type, conn=atlas_conn):
    
    if type(from_ids)!=list:
        from_ids = [from_ids]
    
    if change_type == "merge":
        for curr_rec in from_ids:
            query = """EXEC Atlas_Stage.dbo.hzn_atlas_create_new_merge @merge_from_account = N'{0}' -- nvarchar(255)
            , @merge_to_account = N'{1}' -- nvarchar(255)
            , @username = N'{2}' -- nvarchar(255)""".format(curr_rec, into_id, username)

            ret = conn.execute(query)

    elif change_type == "split":
        for curr_rec in from_ids:        
            query = """EXEC dbo.hzn_atlas_create_new_split @split_source_account = N'{0}' -- source_account_id_py
                , @split_override_account = N'{1}' -- new account for that source_account_id_py
                , @username = N'{2}'""".format(curr_rec, into_id, username)
            ret = conn.execute(query)

    conn.commit()

    # _process_quarantine()

def split_accounts(split_source_account_id_py, into_id, username, conn=atlas_conn):

    if type(split_source_account_id_py)!=list:
        split_source_account_id_py = [split_source_account_id_py]
    
    for id in split_source_account_id_py:
        res = pd.read_sql("select * from source_accounts_log where source_account_id_py = '{0}'".format(id),con=conn)
        if len(res)<1:
            raise ValueError ("split_id {0} not in source_accounts_log".format(id))
    res = pd.read_sql("select * from source_accounts_log where account_id = '{0}'".format(into_id),con=conn)

    if len(res) != 0:
        print("merge_id {0} already exists in source_accounts_log these ids will be added to that account".format(into_id))

    _change_accounts(split_source_account_id_py, into_id, username, "split", conn=conn)

def merge_accounts(merge_account_ids, into_id, username, conn=atlas_conn):

    if type(merge_account_ids)!=list:
        merge_account_ids = [merge_account_ids]

    is_account_id = merge_account_ids[0].isdigit()

    
    for id in merge_account_ids:

        if is_account_id:
            res = pd.read_sql("select * from source_accounts_log where account_id = '{0}'".format(id),con=conn)
            
        else:
            res = pd.read_sql("select * from source_accounts_log where source_account_id_py = '{0}'".format(id),con=conn)

        if len(res)<1:
            raise ValueError ("merge_account_id {0} not in source_accounts_log".format(id))


    res = pd.read_sql("select * from source_accounts_log where account_id = '{0}'".format(into_id),con=conn)

    if len(res)  < 1:
        raise ValueError ("into_id {0} not in source_accounts_log".format(into_id))
    
    if is_account_id:
        _change_accounts(merge_account_ids, into_id, username, "merge", conn=conn)
    else:
        _change_accounts(merge_account_ids, into_id, username, "split", conn=conn)


def clustering_review (df, x):
    df.loc[df['match'].isnull(),'match'] = 0.0

    # Get updated heirarchy for data souces so that the sales data and other important sources are tackled first
    query = """SELECT data_source, quarantine_account_ranking FROM mstr_hierarchy"""
    quarantine_hierarchy = pd.read_sql(query, con=atlas_conn)
    df = df.merge(quarantine_hierarchy, on='data_source', how='left').sort_values('quarantine_account_ranking').reset_index()

    if len(df)>0:

        #Find the best possible match from all the choices
        qc_df = df.groupby(['cluster_id','match']).agg({'source_account_id_py':'count','name_similarity':'max','distance':'min','aff_score':'max','account_type_match':'max','addr_similarity':'max' })
        qc_df.rename(columns = {'source_account_id_py':'records'},inplace = True)
        qc_df.reset_index(inplace = True)

        quarantine_recs = df.groupby(['cluster_id']).agg({'source_account_id_py':'count','account_type':'nunique'}).sort_values(['account_type','source_account_id_py']).reset_index()

        curr_rec = quarantine_recs.loc[x,'cluster_id']

        curr_df = df[df['cluster_id']==curr_rec].sort_values(['match'],ascending = False)
        curr_df = pd.merge(curr_df,hcp_affils,how = 'left',on = ['account_id'])
        curr_id = curr_df['tgt_source_account_id_py'].unique()[0]

    else:
        print('no more records to cluster')

    return df, qc_df, curr_df, curr_rec

def self_clustering_review(df, x):
    query = """select account_id, source_account_id_py, source_acct_name, data_source, address1, soc_type, date_added from source_accounts_log"""
    source_df = pd.read_sql(query,atlas_conn)


    if len(df)>0:
        quarantine_recs = df.groupby(['cluster_id']).agg({'account_id':'count'}).reset_index()
        curr_id = quarantine_recs.loc[x,'cluster_id']
        curr_df = df[df['cluster_id'] ==curr_id].sort_values(['account_id'],ascending = False)
    
        curr_recs = pd.unique(curr_df[['account_id','account_id_tgt']].values.ravel('K'))
        curr_source = source_df[source_df['account_id'].isin(curr_recs)].sort_values(['account_id'])
    
        curr_acct_ids = curr_source['account_id'].unique().tolist()
    else:
        print('no more records to cluster')

    return curr_id, curr_source, curr_acct_ids

def sp_clustering_review(df, x):
    df.loc[df['match'].isnull(),'match'] = 0.0

    if len(df)>0:

        qc_df = df.groupby(['cluster_id','match']).agg({'source_account_id_py':'count','name_similarity':'max','primary_affil_score':'max','addr_similarity':'max' })
        qc_df.rename(columns = {'source_account_id_py':'records'},inplace = True)
        qc_df.reset_index(inplace = True)
    
    
        quarantine_recs = df.groupby(['cluster_id']).agg({'source_account_id_py':'count'}).sort_values('source_account_id_py').reset_index()
        curr_rec = quarantine_recs.loc[x,'cluster_id']
    
        curr_df = df[df['cluster_id']==curr_rec].sort_values(['match'],ascending = False)
        curr_df.rename(columns={'city':'city_sp', 'state':'state_sp', 'zip':'zip_sp'}, inplace=True)
        curr_id = curr_df['source_sp_id_py'].unique()[0]
    
        
    else:
        print('no more records to cluster')
    return df, qc_df, curr_df, curr_rec

def bad_address_review (df, x):
    if len(df)>0:
        curr_addr = df.iloc[[x]]
    
    else:
        print('no more addresses to fix')

    return curr_addr

def bad_geolocation_review(df, x):
    if len(df) > 0:
        curr_addr = df.iloc[[x]]
    else:
        print('no more addresses to fix')

    return curr_addr


def self_clustering_assign(merge, curr_id, curr_acct_ids, user_name):
    print(curr_acct_ids)
    if merge == 'yes':
        for x in curr_acct_ids[1:]:
            insert = """INSERT INTO dbo.self_clustering_review_log ( cluster_id, merge_result,keep_account, merge_account, reviewed_by, date_reviewed )
                        VALUES( '{0}',1 ,'{2}','{3}', '{4}',convert(datetime2, '{1}'))""".format(curr_id, datetime.datetime.now(),curr_acct_ids[0],x,user_name)
            ret = atlas_conn.execute(insert)
            print(insert)
            atlas_conn.commit()
            print("Done!")
    elif merge =='no':
        insert = """INSERT INTO dbo.self_clustering_review_log ( cluster_id, merge_result, reviewed_by, date_reviewed )
                    VALUES( '{0}',0 , '{2}',convert(datetime2, '{1}'))""".format(curr_id, datetime.datetime.now(),user_name)
        ret = atlas_conn.execute(insert)
        print(insert)
        atlas_conn.commit()
        print("Done!")
    else:
        for x in merge[1:]:
            insert = """INSERT INTO dbo.self_clustering_review_log ( cluster_id, merge_result,keep_account, merge_account, reviewed_by, date_reviewed )
                        VALUES( '{0}',1 ,'{2}','{3}', '{4}',convert(datetime2, '{1}'))""".format(curr_id, datetime.datetime.now(),merge[0],x, user_name)
            ret = atlas_conn.execute(insert)
            print(insert)
            atlas_conn.commit()
            print("Done!")

def sp_and_clustering_assign (issue_type, choice, curr_id, curr_rec, user_name):
    if issue_type == 'clustering':
        if choice=='nomatch':
            insert = """INSERT INTO dbo.quarantine_assignment ( tgt_source_account_id_py, username )
                    VALUES( N'{0}' , '{1}')""".format(curr_id, user_name)
            ret = atlas_conn.execute(insert)
            atlas_conn.commit()
            print(insert)
            insert = """INSERT INTO dbo.quarantine_action (tgt_source_account_id_py, source_account_id_py, create_new_account, [user], date_added)
                    VALUES ('{0}', NULL, 1, '{1}', convert(datetime2, '{2}'))""".format(curr_id, user_name, datetime.datetime.now())
            ret = atlas_conn.execute(insert)
            atlas_conn.commit()
            print("Done!")
        else:
            insert = """INSERT INTO dbo.quarantine_assignment ( tgt_source_account_id_py, username)
                    VALUES( N'{0}' , '{1}')""".format(curr_id, user_name)
            ret = atlas_conn.execute(insert)
            atlas_conn.commit()
            print(insert)
            insert = """INSERT INTO dbo.quarantine_action (tgt_source_account_id_py, source_account_id_py, create_new_account, [user], date_added)
                    VALUES ('{0}', '{1}', 0, '{2}', convert(datetime2, '{3}'))""".format(curr_id, choice, user_name, datetime.datetime.now())
            ret = atlas_conn.execute(insert)
            atlas_conn.commit()
            print("Done!")
        
    
    else:
        if choice == 'nomatch':
            insert = """INSERT INTO dbo.quarantine_sp_assignment (cluster_id, username, date_added)
                    VALUES ('{0}', '{1}', convert(datetime2, '{2}'))""".format(curr_rec, user_name, datetime.datetime.now())
            ret = atlas_conn.execute(insert)
            atlas_conn.commit()
            insert = """INSERT INTO dbo.quarantine_sp_action (source_sp_id_py, source_account_id_py, cluster_id, create_new_account, [user], date_added)
            VALUES('{0}', NULL,'{1}', 1, '{2}', convert(datetime2, '{3}'))""".format(curr_id, curr_rec, user_name, datetime.datetime.now())
            ret = atlas_conn.execute(insert)
            print(insert)
            atlas_conn.commit()

            update = """UPDATE dbo.quarantine_sp_assignment
                        SET date_processed = convert(datetime2, '{0}')
                        WHERE username = '{1}'
                        AND cluster_id = '{2}'""".format(datetime.datetime.now(), user_name, curr_rec)
            ret = atlas_conn.execute(update)
            atlas_conn.commit()
            print("Done!")
        else:
            insert = """INSERT INTO dbo.quarantine_sp_assignment (cluster_id, username, date_added)
                    VALUES ('{0}', '{1}', convert(datetime2, '{2}'))""".format(curr_rec, user_name, datetime.datetime.now())
            ret = atlas_conn.execute(insert)
            atlas_conn.commit()
            insert = """INSERT INTO dbo.quarantine_sp_action (source_sp_id_py, source_account_id_py, cluster_id, create_new_account, [user], date_added)
                        VALUES('{0}', '{1}', '{2}', 0, '{3}', convert(datetime2, '{4}'))""".format(curr_id, choice, curr_rec, user_name, datetime.datetime.now())
            ret = atlas_conn.execute(insert)
            print(insert)
            update = """UPDATE dbo.quarantine_sp_assignment
                SET date_processed = convert(datetime2, '{0}')
                WHERE username = '{1}'
                AND cluster_id = '{2}'""".format(datetime.datetime.now(), user_name, curr_rec)
            ret = atlas_conn.execute(update)
            atlas_conn.commit()
            print("Done!")

def bad_address_assign(addr, curr_rec, user_name, city, state, zip, lat, long, fixed):
    if fixed:
        update = """UPDATE bad_address_quarantine
                    SET fixed_address_1 = '{0}', fixed_city= '{1}', fixed_state = '{2}', fixed_zipcode= '{3}',review=1, fixed=1, fixed_latitude={4}, fixed_longitude={5}, username='{7}',
                    date_reviewed= convert(datetime2, '{8}'), date_fixed= convert(datetime2, '{8}') WHERE record_hash = '{6}'""".format(addr, city, state, zip, lat, long, curr_rec, user_name, datetime.datetime.now())
        print(update)
        ret = atlas_conn.execute(update)
        atlas_conn.commit()
        query = """SELECT  glq.addr_hash, fixed_address_1, fixed_city, fixed_state, fixed_zipcode, fixed_latitude, fixed_longitude
                    FROM	bad_address_quarantine baq
                    JOIN	stage_accounts_log sal ON sal.record_hash= baq.record_hash --glq.addr_hash
                    JOIN	Geolocation.dbo.geomatched_low_qual glq ON glq.addr_hash=sal.addr_hash
                    WHERE	fixed=1 and baq.record_hash='{0}'""".format(curr_rec)
        df = pd.read_sql(query, atlas_conn)
        if len(df) > 0:
            for index, row in df.iterrows():
                insert = """insert into geomatched_addresses (addr_hash, returned_address1, returned_city, returned_state, returned_zip, latitude, longitude, geo_process, date_added)
                    VALUES('{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', 'QC BAQ Fixed', convert(datetime2, '{7}'))""".format(row['addr_hash'], row['fixed_address_1'], row['fixed_city'], row['fixed_state'], row['fixed_zipcode'], row['fixed_latitude'], row['fixed_longitude'], datetime.datetime.now())
                ret = geolocation_conn.execute(insert)
                geolocation_conn.commit()
                delete = """delete from geomatched_low_qual where addr_hash = '{0}'""".format(row['addr_hash'])
                ret = geolocation_conn.execute(delete)
                geolocation_conn.commit()
                break
        else:
            print("Could not find")
        print("Done!")
    else:
        update = """UPDATE bad_address_quarantine
                    SET fixed_address_1 = '{0}', review=1, username='{2}', date_reviewed= convert(datetime2, '{3}')
                    WHERE record_hash = '{1}'""".format(addr, curr_rec, user_name, datetime.datetime.now())
        print(update)
        ret = atlas_conn.execute(update)
        atlas_conn.commit()
        print("Done!")

def bad_geolocation_assign(fixed_lat, fixed_long, curr_rec, user_name):
    insert = """INSERT geomatched_fixed_low_qual (addr_hash, fixed_latitude, fixed_longitude, username, date_added)
                VALUES('{0}', '{1}', '{2}', '{3}', convert(datetime2, '{4}'))""".format(curr_rec, fixed_lat, fixed_long, user_name, datetime.datetime.now())
    ret = geolocation_conn.execute(insert)
    print(insert)
    geolocation_conn.commit()
    print("Done!")
            

class QuarantineQC:
    def __init__(self, conn, user_name, include_all=False):
        #define connections
        self.conn = conn
        self.user_name = user_name
        self.include_all = include_all
    
        self.record_num=0
        self.push_flag = 0 #To make sure to only push to table once
        self.next_flag = 0 #Not move to the next record without assigning

        self.full_product_list = ['867a', 'Exfactory', 'SP', 'Tep_867', 'Tep_SP', 'Tep_Exfactory', 'Uplizna_SOC', 'veeva_soc']

        #Get the product to filter to only those sources.
        while True:
            try:
                self.product_type = input("Enter your product {KXX OR TEP UPN OR VEEVA OR ALL}: ").upper()
            except ValueError:
                print("Sorry, I didn't understand that.")
                continue
            if self.product_type not in ('KXX', 'TEP', 'UPN', 'VEEVA', 'ALL'):
                print('Please enter a correct product abbreviation. Enter ALL for all records.')
                continue
            else:
                break
        self.product_list = self.set_product_list()


        print('The username is: '+user_name + '\n')
        if self.product_type not in ('KXX', 'TEP', 'UPN', 'VEEVA'):
            print('All products were selected.\n')
        else:
            print('The product selected is: '+self.product_type + '\n')
        self.describe_data()
    
    #Get the list of products for the specific product type entered
    def set_product_list(self):
        list = []
        if self.product_type == 'KXX':
            list = self.full_product_list[:3]
        elif self.product_type == 'TEP':
            list = self.full_product_list[3:6]
        elif self.product_type == 'UPN':
            list = self.full_product_list[6:7]
        elif self.product_type == 'VEEVA':
            list = self.full_product_list[7:]
        else:
            return []
        
        return list

    def set_issue_type(self):
        
        while True:
            
            try:
                self.issue_type = input("Enter a issue type (clustering, self_clustering, sp_clustering, bad_address, bad_geolocation) : ")
            except ValueError:
                print("Sorry, I didn't understand that.")
                continue
            if self.issue_type not in ('clustering', 'self_clustering', 'sp_clustering', 'bad_address', 'bad_geolocation'):
                print('Please enter a issue type that needs QCing')
                continue
            else:
                print(self.issue_type + ' was selected!')
                break
            


    def define_df(self, issue_type):
        if issue_type == 'clustering':
            # If no prodicts or all products are selected
            if not self.product_list:
                # This flag checks if all rows are to be shown or just ordering records.
                if self.include_all == True:
                    query = """SELECT cl.*, sal.date_added, sl.date_added as tgt_date_added FROM clustering_log cl
                                LEFT JOIN source_accounts_log sal
                                ON cl.source_account_id_py=sal.source_account_id_py
								LEFT JOIN source_accounts_log sl
								ON cl.tgt_source_account_id_py=sl.source_account_id_py
                                WHERE cluster_id IN (select cluster_id from quarantine_log) AND [tgt_source_account_id_py]
                                    NOT IN (select [tgt_source_account_id_py]
                                    FROM quarantine_assignment) order by match desc;"""
                else:
                    query = """SELECT cl.*, sal.date_added, sl.date_added as tgt_date_added FROM clustering_log cl
                                LEFT JOIN source_accounts_log sal
                                ON cl.source_account_id_py=sal.source_account_id_py
								LEFT JOIN source_accounts_log sl
								ON cl.tgt_source_account_id_py=sl.source_account_id_py
                                WHERE cluster_id IN (select cluster_id from quarantine_log) AND [tgt_source_account_id_py]
                                    NOT IN (select [tgt_source_account_id_py]
                                    FROM quarantine_assignment) AND data_source_tgt in ({0}) order by match desc""".format(str(self.full_product_list)[1:-1])
            else:
                query = """SELECT cl.*, sal.date_added, sl.date_added as tgt_date_added FROM clustering_log cl
                            LEFT JOIN source_accounts_log sal
                            ON cl.source_account_id_py=sal.source_account_id_py
                            LEFT JOIN source_accounts_log sl
                            ON cl.tgt_source_account_id_py=sl.source_account_id_py
                            WHERE cluster_id IN (select cluster_id from quarantine_log) AND [tgt_source_account_id_py]
                                NOT IN (select [tgt_source_account_id_py]
                                FROM quarantine_assignment) AND data_source_tgt in ({0}) order by match desc""".format(str(self.product_list)[1:-1])
            self.df = pd.read_sql(query, atlas_conn)
            self.df = self.df.drop_duplicates()
            return self.df

        elif issue_type == 'self_clustering':
            if not self.product_list:
                if self.include_all == True:
                    query = """SELECT scl.* FROM self_clustering_log scl
                                LEFT JOIN self_clustering_review_log slr on scl.cluster_id=slr.cluster_id
                                LEFT JOIN account_action_log aal ON scl.account_id_tgt = aal.merge_from_account
                                    WHERE slr.cluster_id is null and merge_from_account is null"""
                else:
                    query = """SELECT scl.* FROM self_clustering_log scl
                                LEFT JOIN self_clustering_review_log slr on scl.cluster_id=slr.cluster_id
                                LEFT JOIN account_action_log aal ON scl.account_id_tgt = aal.merge_from_account
                                    WHERE slr.cluster_id is null and merge_from_account is null
                                    AND data_source in ({0})""".format(str(self.full_product_list)[1:-1])
            else:
                query = """SELECT scl.* FROM self_clustering_log scl
                                LEFT JOIN self_clustering_review_log slr on scl.cluster_id=slr.cluster_id
                                LEFT JOIN account_action_log aal ON scl.account_id_tgt = aal.merge_from_account
                                    WHERE slr.cluster_id is null and merge_from_account is null
                                    AND data_source in ({0})""".format(str(self.product_list)[1:-1])
            
            self.df = pd.read_sql(query, atlas_conn)
            self.df = self.df.drop_duplicates()
            return self.df

        elif issue_type == 'sp_clustering':
            query = """SELECT scl.*, spl.city, spl.state, spl.zip FROM sp_clustering_log scl
                        JOIN source_sp_log spl
                        ON scl.source_sp_id_py=spl.source_sp_id_py
                        LEFT JOIN match_sp_log msl on scl.cluster_id=msl.cluster_id
                        LEFT JOIN quarantine_sp_action qsa on scl.cluster_id=qsa.cluster_id
                        WHERE msl.cluster_id is null AND qsa.cluster_id is null"""
            self.df = pd.read_sql(query, atlas_conn)
            self.df = self.df.drop_duplicates()
            return self.df

        elif issue_type == 'bad_address':
            if not self.product_list:
                if self.include_all == True:
                    query = """SELECT sal.data_source, sal.source_acct_name, CONCAT(baq.source_address1,' ', baq.source_address_2) AS 'address1', baq.source_city AS city, baq.source_state AS state,
                                baq.source_zip AS zip, baq.record_hash FROM bad_address_quarantine baq
		                        JOIN stage_accounts_log sal ON baq.record_hash= sal.record_hash
                                WHERE ISNULL(fixed,0) = 0 AND ISNULL(review,0) = 0"""
                    self.df = pd.read_sql(query, atlas_conn)
                else:
                    query = """SELECT sal.data_source, sal.source_acct_name, CONCAT(baq.source_address1,' ', source_address_2) AS 'address1', baq.source_city AS city, baq.source_state AS state,
                                    baq.source_zip AS zip, baq.record_hash FROM bad_address_quarantine baq
		                        JOIN stage_accounts_log sal ON baq.record_hash= sal.record_hash
                                WHERE ISNULL(fixed,0) = 0 AND ISNULL(review,0) = 0 AND sal.data_source in ({0})""".format(str(self.full_product_list)[1:-1])
                    self.df = pd.read_sql(query, atlas_conn)
            else:
                if ('867a') in self.product_list:
                    query = """SELECT sal.data_source, sal.source_acct_name, CONCAT(baq.source_address1,' ', source_address_2) AS 'address1', baq.source_city AS city, baq.source_state AS state,
                                    baq.source_zip AS zip, baq.record_hash
                                    FROM bad_address_quarantine AS baq
                                    JOIN dbo.stage_sp_log AS sal ON baq.record_hash = sal.record_hash
                                    WHERE sal.product IN ('KRYSTEXXA') and ISNULL(fixed,0) = 0 AND ISNULL(review,0) = 0"""
                    self.df = pd.read_sql(query, atlas_conn)

                else:
                    query = """SELECT sal.data_source, sal.source_acct_name, CONCAT(baq.source_address1,' ', source_address_2) AS 'address1', baq.source_city AS city, baq.source_state AS state,
                            baq.source_zip AS zip, baq.record_hash FROM bad_address_quarantine baq
		                    JOIN stage_accounts_log sal ON baq.record_hash= sal.record_hash
                            WHERE ISNULL(fixed,0) = 0 AND ISNULL(review,0) = 0 AND sal.data_source in ({0})""".format(str(self.product_list)[1:-1])
                    self.df = pd.read_sql(query, atlas_conn)
            self.df = self.df.drop_duplicates()
            return self.df

        elif issue_type == 'bad_geolocation':
            if not self.product_list:
                if self.include_all == True:
                    query = """SELECT address1, city, state, zip, glq.addr_hash, latitude, longitude, api, accuracy, accuracy_type, geo_process
                                FROM geomatched_low_qual glq
                                JOIN Atlas_Stage.dbo.stage_accounts_log sal on glq.addr_hash=sal.addr_hash
                                LEFT JOIN Atlas_Stage.dbo.bad_address_quarantine baq ON sal.record_hash=baq.record_hash
                                WHERE glq.addr_hash NOT IN (SELECT addr_hash FROM geomatched_fixed_low_qual)
                                    AND baq.record_hash is null"""
                else:
                    query = """SELECT address1, city, state, zip, glq.addr_hash, latitude, longitude, api, accuracy, accuracy_type, geo_process
                                FROM geomatched_low_qual glq
                                JOIN Atlas_Stage.dbo.stage_accounts_log sal on glq.addr_hash=sal.addr_hash
                                LEFT JOIN Atlas_Stage.dbo.bad_address_quarantine baq ON sal.record_hash=baq.record_hash
                                WHERE glq.addr_hash NOT IN (SELECT addr_hash FROM geomatched_fixed_low_qual)
                                AND baq.record_hash is null sal.data_source in ({0})""".format(str(self.full_product_list)[1:-1])
            else:
                query = """SELECT address1, city, state, zip, glq.addr_hash, latitude, longitude, api, accuracy, accuracy_type, geo_process
                                FROM geomatched_low_qual glq
                                JOIN Atlas_Stage.dbo.stage_accounts_log sal on glq.addr_hash=sal.addr_hash
                                LEFT JOIN Atlas_Stage.dbo.bad_address_quarantine baq ON sal.record_hash=baq.record_hash
                                WHERE glq.addr_hash NOT IN (SELECT addr_hash FROM geomatched_fixed_low_qual)
                                AND baq.record_hash is null AND sal.data_source in ({0})""".format(str(self.product_list)[1:-1])
            self.df = pd.read_sql(query, geolocation_conn)
            self.df = self.df.drop_duplicates()
            return self.df

    def describe_data(self):
        self.clustering_df = self.define_df('clustering')
        print("There are " + str(self.clustering_df.cluster_id.nunique()) + " records left to check in clustering.\n")
        
        self.self_clustering_df = self.define_df('self_clustering')
        print("There are " + str(self.self_clustering_df.cluster_id.nunique()) + " records left to check in self clustering.\n")

        self.sp_clustering_df = self.define_df('sp_clustering')
        print("There are " + str(self.sp_clustering_df.cluster_id.nunique()) + " records left to check in sp clustering.\n")
        self.bad_address_df = self.define_df('bad_address')
        print("There are " + str(self.bad_address_df.record_hash.nunique()) + " bad addresses to fix.\n")

        self.bad_geolocation_df = self.define_df('bad_geolocation')
        print("There are " + str(self.bad_geolocation_df.addr_hash.nunique()) + " bad geolocations to fix.\n")


    def next_record(self, display_kepler=False):
        if self.next_flag == 1:
            print("Try Assigning the record first before moving to next_record")
        if self.issue_type == 'clustering':
            clustering_df = self.define_df('clustering')
            df, qc_df, curr_df, curr_rec = clustering_review(self.clustering_df, self.record_num)
            self.id_list = curr_df.tgt_source_account_id_py.astype(str).to_list()[:1]
            self.id_list = self.id_list + curr_df.account_id.astype(str).unique().tolist()
            
            print("\nThe record that needs to be clustered (clustering record):")
            curr_df = curr_df.rename(columns={'tgt_source_account_id_py':'record_source_account_id_py', 'source_acct_name_tgt': 'source_acct_name_record', 'data_source_tgt':'data_source_record', \
                                                'address1_tgt':'address1_record', 'soc_type_tgt':'soc_type_record', 'tgt_date_added':'record_date_added'})
            display(curr_df[['record_source_account_id_py','source_acct_name_record','data_source_record','address1_record','soc_type_record', 'record_date_added']].drop_duplicates())
            
            print("\nThe potential source accounts that the record can cluster to:")
            display(curr_df[['account_id','source_account_id_py','source_acct_name','data_source','match','distance','address1','account_type','soc_type','affil_hcps','name_similarity','addr_similarity', 'date_added']])
            
            if display_kepler:
                display(HTML("<iframe src='https://datascience.horizontherapeutics.com/map/atlas/{0}' height=350 width=700>".format("_".join(self.id_list))))
            self.next_flag = 1
            self.push_flag = 0

        elif self.issue_type == 'self_clustering':
            self_clustering_df = self.define_df('self_clustering')
            curr_id, curr_source, curr_acct_ids = self_clustering_review(self.self_clustering_df, self.record_num)

            self.id_list = curr_source.source_account_id_py.astype(str).unique().tolist()
            self.id_list = self.id_list + curr_source.account_id.astype(str).unique().tolist()

            print("The current sources:")
            display(curr_source)

            print("\nThe distinct account_ids: ")
            display(curr_acct_ids)

            if display_kepler:
                display(HTML("<iframe src='https://datascience.horizontherapeutics.com/map/atlas/{0}' height=350 width=700>".format("_".join(self.id_list))))

            self.next_flag = 1
            self.push_flag = 0

        elif self.issue_type == 'sp_clustering':
            df, qc_df, curr_df, curr_rec = sp_clustering_review(self.sp_clustering_df, self.record_num)

            self.id_list = curr_df.source_sp_id_py.astype(str).to_list()[:1]
            self.id_list = self.id_list + curr_df.account_id.astype(str).unique().tolist()
            
            print("\nThe SP record that needs to be clustered: ")

            display(curr_df[['source_acct_name_sp', 'npi_sp', 'address1_sp', 'city_sp', 'state_sp', 'zip_sp']].drop_duplicates())
            
            print("\nThe potential source accounts that the sp record can cluster to: ")
            display(curr_df[['account_id','source_account_id_py','entity_name', 'entity_type', 'data_source', 'address1', 'hcp_npi', 'primary_affil_score','name_similarity','addr_similarity', 'name_addr_sim' ,'match']])
            
            if display_kepler:
                display(HTML("<iframe src='https://datascience.horizontherapeutics.com/map/atlas/{0}' height=350 width=700>".format("_".join(self.id_list))))
            self.next_flag = 1
            self.push_flag = 0

        elif self.issue_type == 'bad_address':
            curr_addr = bad_address_review(self.bad_address_df, self.record_num)

            print("Current address to fix")
            display(curr_addr)

            self.next_flag = 1
            self.push_flag = 0

        elif self.issue_type == 'bad_geolocation':
            curr_addr = bad_geolocation_review(self.bad_geolocation_df, self.record_num)

            print("Current geolocation to fix")
            display(curr_addr)

            self.next_flag = 1
            self.push_flag = 0

    def skip_record(self):
        self.record_num = self.record_num + 1
        self.push_flag = 0
        self.next_flag = 0
        print("Record skipped! Call next_record() to see the next record")

    #Assigin records to the database    
    def assign_record(self, **kwargs): #clustering_choice, fixed_address, fixed_lat, fixed_long
        if self.issue_type in ('clustering', 'self_clustering', 'sp_clustering'):
            if ('fixed_address')  in kwargs or ('fixed_lat_long') in kwargs:
                raise ValueError("Can't take address fix for clustering")
        elif self.issue_type == 'bad_geolocation':
            if 'clustering_choice' in kwargs or 'fixed_address' in kwargs:
                raise ValueError("Can't take a clustering or bad_address fix for Geolocation. Please send latitude and longitude only.")
        elif self.issue_type == 'bad_address':
            if 'clustering_choice' in kwargs:
                raise ValueError("Can't take a clustering fix for bad address. Please send full address or full address and lat/long.")
            if ('fixed_lat_long') in kwargs:
                raise ValueError("Can't take geolocation fix only for address fix")
        
        if self.push_flag == 0:
            if self.issue_type == 'clustering':
                clustering_choice = kwargs['clustering_choice']
                df, qc_df, curr_df, curr_rec = clustering_review(self.clustering_df, self.record_num)

                curr_id = curr_df['tgt_source_account_id_py'].unique()[0]
                sp_and_clustering_assign (self.issue_type, clustering_choice, curr_id, curr_rec, self.user_name)
                self.next_flag = 0
                self.push_flag = 1
                self.record_num= self.record_num + 1

            elif self.issue_type == 'self_clustering':
                clustering_choice = kwargs['clustering_choice']
                curr_id, curr_source, curr_acct_ids = self_clustering_review(self.self_clustering_df, self.record_num)

                self_clustering_assign(clustering_choice, curr_id, curr_acct_ids, self.user_name)
                self.next_flag = 0
                self.push_flag = 1
                self.record_num= self.record_num + 1


            elif self.issue_type == 'sp_clustering':
                clustering_choice = kwargs['clustering_choice']
                df, qc_df, curr_df, curr_rec = sp_clustering_review(self.sp_clustering_df, self.record_num)
                curr_id = curr_df['source_sp_id_py'].unique()[0]

                sp_and_clustering_assign (self.issue_type, clustering_choice, curr_id, curr_rec, self.user_name)
                self.next_flag = 0
                self.push_flag = 1
                self.record_num= self.record_num + 1

            elif self.issue_type == 'bad_address':
                curr_addr = bad_address_review(self.bad_address_df, self.record_num)

                if ('fixed_address') in kwargs and ('fixed_city') in kwargs and ('fixed_state') in kwargs and ('fixed_zip') in kwargs:
                    address = kwargs['fixed_address']
                    city = kwargs['fixed_city']
                    state = kwargs['fixed_state']
                    zip = kwargs['fixed_zip']
                    lat = kwargs['fixed_lat']
                    long = kwargs['fixed_long']
                    bad_address_assign(address, curr_addr.loc[self.record_num, 'record_hash'], self.user_name, city, state, zip, lat, long, fixed=True)
                else:
                    bad_address_assign('incomplete', curr_addr.loc[self.record_num, 'record_hash'], self.user_name, None, None, None, 0.0, 0.0, fixed=False)
                self.next_flag = 0
                self.push_flag = 1
                self.record_num= self.record_num + 1

            elif self.issue_type == 'bad_geolocation':
                fixed_lat_long = kwargs['fixed_lat_long']
                curr_addr = bad_geolocation_review(self.bad_geolocation_df, self.record_num)
                if len(fixed_lat_long.split(',')) !=2:
                    raise ValueError("Incorrect format! Please enter latitude, longitude format")

                else:
                    fixed_lat = fixed_lat_long.split(',')[0].strip()
                    fixed_long = fixed_lat_long.split(',')[1].strip()
                    bad_geolocation_assign(fixed_lat, fixed_long, curr_addr.loc[self.record_num, 'addr_hash'], self.user_name)
                    self.next_flag = 0
                    self.push_flag = 1
                    self.record_num= self.record_num + 1

        else:
            print("This has already been assigned.")
