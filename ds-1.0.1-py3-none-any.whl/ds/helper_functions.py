import bisect
import getpass
import math
import ntpath
import os
import re
import smtplib
import time
import urllib
from email.mime.application import MIMEApplication
from email.mime.image import MIMEImage
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

import pandas as pd
import pymongo
import pyodbc
import sqlalchemy
from dotenv import load_dotenv
from neo4j import GraphDatabase
from scipy.sparse.csgraph import connected_components

load_dotenv(os.path.join(os.path.dirname(__file__),'.env'))
# locale.setlocale(locale.LC_ALL, 'en_US.UTF-8')

current_time = lambda : time.localtime()
long_date = lambda : time.strftime("%Y-%m-%dT%H:%M:%S", time.localtime())
short_date = lambda : time.strftime("%Y%m%d", time.localtime())

# used for platform code on location of shared drive of USLSACADS1
# posix means linux and is running on ds1
# windows is any other type of system/server dsf2, sql1, sql2
if os.name == "posix":
    path_prefix = "/shares/Shared/"
else:
    path_prefix = "Z:/"

def path(dir_path, *args):
    """
    Parameters
    ------------
    dir_path : string
        Path of directory wanted to use

    Returns
    -------
    current_path : string
        cleaned path of directory being used    

    """
    dir_path = dir_path.replace("\\","/")
    if path_prefix in dir_path:
        current_path = os.path.join(dir_path, *args)
    else:
        current_path = os.path.join(path_prefix, dir_path, *args)
    current_path = current_path.replace("\\","/")
    
    return current_path

def project_path(username, project_name):
    """
    This function returns a platform specific path to a project

    Parameters
    ------------
    
    username : string
        Name of the project author.

    project_name : string
        Name of project being worked on.


    Returns
    -------
    path : str
        Platform specific project path

    """

    return path(os.path.join(path_prefix, "Projects", "Adhoc", username, project_name)) 


def left_anti(df1,df2,cols):

    """
    Parameters
    ------------
    df1 : pandas dataframe
        DataFrame containing unique and duplicate data.

    df2 : pandas dataframe
        DataFrame overlapping data with df1.

    cols : list
        List of columns to join on.

    Returns
    -------

    df : pandas dataframe 
        DataFrame containing only what is unique to df1 on specified cols

    """
    df1[cols] = df1[cols].astype(str)
    df = df1.merge(df2[cols].astype(str),"left",on=cols,indicator=True)
    df = df[df["_merge"]=="left_only"]
    del df["_merge"]
    return df
    
# connect to SQL server for stored procs
def connect(db="orp", server="USLSACASQL2", engine=False, fast=False, azure=False, azure_type="prod", mongodb=False, neo4j=False):
    """
    Parameters
    ------------
    db : string
        Database to connect to

    server : string
        Which server is going to be connected to
    
    engine : bool
        Return an connection that can write to sql
        
    fast : bool
        An engine connection that runs queries faster. UNDER DEVELOPMENT

    azure : bool
        Will connect to C360 prod database
        
    azure_type : string
        will connect to dev test databases 

    mongodb : bool
        A connection to the Data Science mongodb db

    neo4j : bool
        A connection to the graph db

    Returns
    -------
    conn : the type of connection being made

    """

    if os.name == "posix":
        # connection needs to be by IP
        if server == "USLSACASQL1":
            server ="172.27.10.74"
        if server == "USLSACASQL2":
            server = "172.27.10.79"

        connStr = 'DRIVER={ODBC Driver 17 for SQL Server};SERVER=' + server + ';PORT=1433;DATABASE=' + db + ';UID=hduser;PWD=Horizon55!'
        if engine or fast:
            engine = sqlalchemy.create_engine('mssql+pyodbc:///?odbc_connect=%s' % (urllib.parse.quote_plus(connStr)))
        
            return engine
        elif mongodb:
            MONGO_HOST = "localhost"
            MONGO_PORT = 27017
            return pymongo.MongoClient(MONGO_HOST, MONGO_PORT, username=os.getenv("APOLLO_USERNAME"), password=os.getenv("APOLLO_PASSWORD"))

        elif neo4j:
            return GraphDatabase.driver("bolt://localhost:7687", auth=(os.getenv("NEO4J_USERNAME"), os.getenv("NEO4J_PASSWORD")))
        
        else:
            conn = pyodbc.connect(connStr)
            return conn

    else:
        conn_str = 'DRIVER={SQL Server Native Client 11.0};SERVER=' + server + ';DATABASE=' + db + ';Trusted_Connection=yes'

        if azure:
            username = getpass.getuser()+"@horizontherapeutics.com"
            server = f"hz-hdp-{azure_type}-sql-001.database.windows.net"
            driver = '{ODBC Driver 17 for SQL Server}'
            conn = pyodbc.connect('DRIVER='+driver+';SERVER='+server+';PORT=1433;DATABASE='+db+';UID='+username+';AUTHENTICATION=ActiveDirectoryInteractive')
            return conn

        elif mongodb:
            MONGO_HOST = "uslsacads1"
            MONGO_PORT = 27017
            return pymongo.MongoClient(MONGO_HOST, MONGO_PORT, username=os.getenv("APOLLO_USERNAME"), password=os.getenv("APOLLO_PASSWORD"))

        elif neo4j:
            return GraphDatabase.driver("neo4j+s://8c488106.databases.neo4j.io", auth=(os.getenv("NEO4J_USERNAME"), os.getenv("NEO4J_PASSWORD")))
        
        elif fast:
            
            engine = sqlalchemy.create_engine("mssql+pyodbc://{0}/{1}?trusted_connection=yes&driver=ODBC+Driver+17+for+SQL+Server".format(server,db), fast_executemany=True)
            return engine
        elif engine:
            engine = sqlalchemy.create_engine(
                'mssql+pyodbc:///?odbc_connect=%s' % (
                    urllib.parse.quote_plus(conn_str)))
            return engine
        # connect to SQL server for regular queries
        else:
            conn = pyodbc.connect(conn_str)
            return conn


# function to format datatypes - used for pandas push to_sql
# sample: df.to_sql(dest_tbl, conn, index = False, if_exists='replace',dtype = format_types(data_df))
def format_types(df):
    """
    Parameters
    ------------
    df : pd.DataFrame()
        The dataframe that is being written to sql

    Returns
    -------
    dtypedict : dict
        provides the types of each column of the dataframe

    """
    dtypedict = {}
    for i, j in zip(df.columns, df.dtypes):
        if "object" in str(j):
            dtypedict.update({i: sqlalchemy.types.NVARCHAR(length=255)})

        if "datetime" in str(j):
            dtypedict.update({i: sqlalchemy.types.DateTime()})

        if "float" in str(j):
            dtypedict.update({i: sqlalchemy.types.Float(precision=3, asdecimal=True)})

        if "int" in str(j):
            dtypedict.update({i: sqlalchemy.types.INT()})

        if "bool" in str(j):
            dtypedict.update({i: sqlalchemy.types.Boolean()})

        # if "Notes_MVN__c" in str(i) or 'Management_Note_MVN__c' in str(i) or 'Office_Contact_MVN__c' in str(
        #         i) or "Latest_Case_Note_MVN__c" in str(i):
        #     dtypedict.update({i: sqlalchemy.types.Text()})

    return dtypedict


def sendEmail(to, subj, body, sendFrom='orphan_analytics@horizonpharma.com',
              cc=None, bcc=None, attachments=None, actualFrom='orphan_analytics@horizonpharma.com', imgs=None):
    """
    A function to send emails with python   

    Parameters
    ------------
    
    """
    msg = MIMEMultipart()
    msg['Subject'] = subj
    msg['From'] = sendFrom
    msg['To'] = ','.join(to)
    if cc:
        msg['Cc'] = ','.join(cc)
        to = to + cc
    if bcc:
        msg['Bcc'] = ','.join(bcc)
        to = to + bcc

    msgAlternative = MIMEMultipart('alternative')
    msg.attach(msgAlternative)
    messagePart = MIMEText(body, 'html')
    msgAlternative.attach(messagePart)

    if attachments:
        for attach in attachments:
            attachPart = MIMEApplication(open(attach, "rb").read())
            attachPart.add_header('Content-Disposition', 'attachment', filename=ntpath.basename(attach))
            msg.attach(attachPart)

    if imgs:
        for cid in imgs:
            fp = open(imgs[cid], 'rb')
            msgImage = MIMEImage(fp.read())
            fp.close()

            # Define the image's ID as referenced above
            msgImage.add_header('Content-ID', cid)
            msg.attach(msgImage)

    url = 'smtprelay.horizontherapeutics.local'
    server = smtplib.SMTP(url)
    server.sendmail(actualFrom, to, msg.as_string())
    server.quit()

def reductionFunction(data, start_field, end_field):
    """
    

    Parameters
    ------------
    

    Returns
    -------
    

    """
    # create a 2D graph of connectivity between date ranges
    start = data[start_field].values
    end = data[end_field].values
    graph = (start <= end[:, None]) & (end >= start[:, None])

    # find connected components in this graph
    n_components, indices = connected_components(graph)

    # group the results by these connected components

    data = data.groupby(indices).aggregate({start_field: 'min', end_field: 'max', })
    data[start_field] = pd.to_datetime(data[start_field])
    data[end_field] = pd.to_datetime(data[end_field])
    return data

def ngrams(string, n=3):
    """
    

    Parameters
    ------------
    

    Returns
    -------
    

    """
    string = re.sub(r'[,-./]|\sBD', r'', string)
    grms = zip(*[string[i:] for i in range(n)])
    return [''.join(ngram) for ngram in grms]


def distance(lat1, lon1,lat2, lon2):
    """
    

    Parameters
    ------------
    

    Returns
    -------
    

    """

    radius = 6371 # km

    dlat = math.radians(lat2-lat1)
    dlon = math.radians(lon2-lon1)
    a = math.sin(dlat/2) * math.sin(dlat/2) + math.cos(math.radians(lat1)) \
        * math.cos(math.radians(lat2)) * math.sin(dlon/2) * math.sin(dlon/2)
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1-a))
    d = radius * c
    return d

def get_config(active=False,previous=0,all=False):
    """
    

    Parameters
    ------------
    

    Returns
    -------
    

    """
    config = pd.read_excel("Z:/cluster/infused_product/config/control_file.xlsx","control_file")
    config["version_label"] = config["product_name"] + "_" + config["data_type"]

    if all:
        return config
    if active:
        config = config[config["active"]==1]

    for i in range(previous):
        remove = config[config["source"].notna()].groupby(['product_name','data_type']).agg({"date_created":"max"}).reset_index()
        remove["remove"] = 1
        config = config.merge(remove,"left",["product_name","data_type","date_created"])
        config = config[config["remove"]!= 1]
        del config['remove']

    config = config[config["source"].notna()].groupby(['product_name','data_type']).agg({"date_created":"max"}).reset_index().merge(config,"inner",["product_name","data_type","date_created"])
    return config

def version(version_label,previous=0,config=False):
    """
    

    Parameters
    ------------
    

    Returns
    -------
    

    """
    if not config:
        config = get_config(active=True, previous=previous)
    return config.loc[(config["version_label"]==version_label),"version_name"].item()
    

def get_version(version_label,previous=0,config=False):
    """
    

    Parameters
    ------------
    

    Returns
    -------
    

    """
    if not config:
        config = get_config(previous=previous)
    
    return config.loc[(config["version_label"]==version_label),"version_name"].item()

def get_schema(version_label,version="",config=False):
    """
    returns load schema for current or specified version

    Parameters
    ------------
    

    Returns
    -------
    

    """
    if not config:
        config = get_config(all=True)
    if version=="":
        version = get_version(version_label)
    return config.loc[(config["version_label"]==version_label)&(config["version_name"]==version),"load_schema"].item()

def state_from_zip3(zip3):
    """
    This function returns state from a given 3 digit zip.

    Parameters
    ------------
    
    zip3 : string or int
        3 Digit Zip

    Returns
    -------
    state : str
        State acronym

    """
    if type(zip3) == str:
        zip3 = int(zip3)
    special_zips = {0: 'PLACEHOLDER OR INCORRECT ADDRESS', 1:'NONE', 2:'NONE', 3:'NONE', 4:'NONE', 5: 'NY', 6: 'PR', 7: 'PR', 8: 'VI', 9: 'PR', 55: 'MA', 201: 'VA', 213: 'NONE', 
            269: 'NONE', 340: 'AA', 343: 'NONE', 345: 'NONE', 348: 'NONE', 353: 'NONE', 419: 'NONE', 428: 'NONE', 429: 'NONE', 517: 'NONE', 518: 'NONE', 519: 'NONE', 
            529: 'NONE', 533: 'NONE', 536: 'NONE', 552: 'NONE', 568: 'NONE', 569:'DC', 578: 'NONE', 579: 'NONE', 589: 'NONE', 621: 'NONE', 632: 'NONE', 642: 'NONE', 
            643: 'NONE', 659: 'NONE', 663: 'NONE', 682: 'NONE', 694: 'NONE', 695: 'NONE', 696: 'NONE', 697: 'NONE',698: 'NONE', 699: 'NONE', 702: 'NONE', 709: 'NONE', 
            715: 'NONE', 732: 'NONE', 733: 'TX', 742: 'NONE', 817: 'NONE', 818: 'NONE', 819: 'NONE', 839: 'NONE', 848: 'NONE', 849: 'NONE', 854: 'NONE', 858: 'NONE', 
            861: 'NONE', 862: 'NONE', 866: 'NONE', 867: 'NONE', 868: 'NONE', 869: 'NONE', 872: 'NONE', 876: 'NONE', 885: 'TX', 886: 'NONE', 887: 'NONE', 888: 'NONE', 
            892: 'NONE', 896: 'NONE', 899: 'NONE', 929: 'NONE', 969: 'GU', 987: 'NONE'}


    if zip3 not in special_zips:
        result = ['MA', 'RI', 'NH', 'ME', 'VT', 'CT', 'NJ', 'AE', 'NY', 'PA', 'DE', 'DC', 'MD', 'VA', 'WV', 'NC', 'SC', 'GA', 'FL', 'AL', 'TN', 'MS', 'GA', 'KY', 'OH',
                  'IN', 'MI', 'IA', 'WI', 'MN', 'SD', 'ND', 'MT', 'IL', 'MO', 'KS', 'NE', 'LA', 'AR', 'OK', 'TX', 'CO', 'WY', 'ID', 'UT', 'AZ', 'NM', 'NV', 'CA', 'AP',
                  'HI', 'OR', 'WA', 'AK']
        map_of_zips = bisect.bisect([28, 30, 39, 50, 60, 70, 90, 100, 150, 197, 200, 206, 220, 247, 269, 290, 300, 320, 350, 370, 386, 398, 400, 428, 460, 480, 500, 530, 550,
                                     569, 578, 590, 600, 630, 660, 680, 693, 715, 730, 750, 800, 817, 832, 839, 848, 866, 885, 900, 962, 967, 969, 980, 995, 1000], zip3)
        return result[map_of_zips]
    else:
        return special_zips[zip3]

def clean_columns(df):
    """
    Cleans column names to remove capitalization and spaces

    Parameters
    ----------
    df : pd.DataFrame
        The df whose columns need to be cleaned
    Returns
    --------
    df : pd.DataFrame
        The same df with sanitized columns
    """
    new_cols = {x:x.lower().replace(" ","_") for x in df.columns}
    return df.rename(columns=new_cols)