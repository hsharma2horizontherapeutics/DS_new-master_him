from datetime import datetime, timedelta

import ds.helper_functions as hf
import numpy as np
from numpy.core.numeric import _full_like_dispatcher
import pandas as pd
import sparse_dot_topn.sparse_dot_topn as ct
from ds.helper_functions import connect, format_types, left_anti, ngrams
from scipy.sparse import csr_matrix
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from tqdm import tqdm


ds_conn = connect(db="DS",server="USLSACASQL2",engine=True)
conn = connect(db="Rosetta",server="USLSACASQL1",engine=True)
cursor = connect(db="Rosetta",server="USLSACASQL1").cursor()

sources = pd.read_sql("select * from rosetta_config_sources",conn)

z_fill = 6


def build_hub_data():
    dfs = []
    for key in queries:
        df=pd.read_sql(queries[key],conn)
        if "enroll_date" not in df.columns:
            df["enroll_date"] = np.nan
        dfs.append(df)

    return pd.concat(dfs)

def build_bridge():
    market = pd.read_sql("select * from uslsacasql2.[MarketAccess_Sandbox].[dbo].[BridgeFromPARCtoPayor_WithId]",conn)
    bridge = pd.read_sql("select * from rosetta_system_pm_payer",conn)
    bridge["insurance_type"] = bridge["insurance_type"].str.lower()
    market["Insurance_Flag "] = market["Insurance_Flag "].str.lower()

    hier = pd.read_sql("""select * from uslsacasql2.[MarketAccess_Sandbox].[dbo].[Horizon_PayorHierarchy]""", conn)
    freeze = pd.read_sql("select * from rosetta_hub_freeze",conn).fillna("")
    current_hub = build_hub_data().fillna('')

    cut_date = datetime(2021,12,31)

    freeze["enroll_date"] = pd.to_datetime(freeze["enroll_date"])

    freeze['payer_name'] = freeze['payer_name'].str.upper()
    freeze["pay_type"] = freeze["pay_type"].str.upper()
    freeze["insurance_type"] = freeze["insurance_type"].str.lower()
    current_hub['payer_name'] = current_hub['payer_name'].str.upper()
    current_hub["pay_type"] = current_hub["pay_type"].str.upper()
    current_hub["insurance_type"] = current_hub["insurance_type"].str.lower()

    freeze["change_index"] = freeze['payer_name']+freeze["pay_type"]+freeze["insurance_type"]

    current_hub["change_index"] = current_hub['payer_name']+current_hub["pay_type"]+current_hub["insurance_type"]
    all_data = freeze.merge(current_hub,"outer",["pm_id","product"],suffixes=("_freeze","_hub"))
    all_data["match"] = all_data["change_index_freeze"] == all_data["change_index_hub"]
    all_data["insurance_type"] = all_data["insurance_type_freeze"].str.lower()


    old_bridge = all_data[(all_data.enroll_date_freeze < cut_date)&(all_data["match"]==True)][["pm_id",'insurance_type',"product"]].drop_duplicates()
    # old_bridge = old_bridge.rename(columns={"Horizon_Index":"horizon_index","Insurance_Flag ":"insurance_type"})
    old_bridge = old_bridge.merge(market.rename(columns={"Horizon_Index":"horizon_index","Insurance_Flag ":"insurance_type"}),"left",["pm_id",'insurance_type',"product"])
    old_bridge = old_bridge.merge(hier[["horizon_index","horizon_payor_id"]],"left",["horizon_index"]).sort_values(by="horizon_payor_id").drop_duplicates(subset=["pm_id","insurance_type","product"])
    old_bridge = old_bridge[['pm_id',"Horizon_Payor",'Horizon_Payor_Type','horizon_index','horizon_payor_id','insurance_type','product']]
    old_bridge["source"] = 'historical'

    # new_bridge = all_data[(all_data.enroll_date_freeze >= cut_date)|(all_data["match"]==False)][["pm_id","insurance_type","product"]].drop_duplicates()
    new_bridge = hf.left_anti(all_data,old_bridge,['pm_id','insurance_type'])[["pm_id","insurance_type","product"]].drop_duplicates()
    new_bridge = new_bridge.merge(bridge,"left",["pm_id",'insurance_type','product'])[['pm_id','payer','payer_type','rosetta_payer_index','precision_id','insurance_type','payer_source','product']]
    new_bridge.columns = ['pm_id',"Horizon_Payor",'Horizon_Payor_Type','horizon_index','horizon_payor_id','insurance_type','source','product']
    full_bridge = pd.concat([old_bridge,new_bridge])
    full_bridge = full_bridge.rename(columns={"Horizon_Payor":"payer",
                                "Horizon_Payor_Type":"payer_type",
                                "horizon_index":"rosetta_payer_index",
                                "horizon_payor_id":"payer_id"})
    full_bridge["payer"] = full_bridge["payer"].str.upper()
    full_bridge["payer_type"] = full_bridge["payer_type"].str.upper()
    full_bridge["rosetta_payer_index"] = full_bridge["rosetta_payer_index"].str.upper()

    full_bridge = full_bridge.drop_duplicates()

    full_bridge["last_updated"] = datetime.now()

    write_sql(full_bridge,"rosetta_system_full_bridge",if_exists="replace")

# matching log functions
def log_match(record_id,source_id,source,user_id):
    write_sql(pd.DataFrame(data=[{"user_name":user_id,"record_id":record_id,"source_id":source_id,"source":source,"assignment_date":hf.long_date()}]),"rosetta_log_assignment")
    return 0

def remove_from_quar(source_id,source):
    cursor.execute("DELETE FROM rosetta_log_quarantine WHERE source_id = ? and source = ?",(source_id,source))
    cursor.commit()
    return 0

def update_match(record_id,source_id,source):
    cursor.execute("update rosetta_potential_matches set record_id_matched = ? where source_matched = ? and source_id_matched = ? ",(record_id,source,source_id))
    cursor.commit()



def build_raw_course_therapy(df):

    df["pay_type"] = df["pay_type"].str.upper()
    df["payer_name"] = df['payer_name'].str.upper()

    # df.loc[(df["pay_type"]=="MEDICARE") & ((df["state"].notna())),"payer_name"] = df["payer_name"] + " " + df["state"]
    df["raw_pay_type"] = df["pay_type"]

    #medicaid logic first row sets default
    df.loc[df["raw_pay_type"]=="MEDICAID","pay_type"] = "MANAGED MEDICAID"

    for x in ['STATE OF', 'DISTRICT OF COLUMBIA', 'TERRITORY OF PUERTO RICO', 'TERRITORY OF VIRGIN ISLANDS']:
        df.loc[df["payer_name"].str.contains(x, na=False),"pay_type"] = "FFS MEDICAID"

    df.loc[df["pay_type"].str.contains("Medicaid Unspecified", na=False),"pay_type"] = "FFS MEDICAID"
    df.loc[(df["payer_name"].isna()) & (df["raw_pay_type"]=="MEDICAID"),"pay_type"] = "FFS MEDICAID"

    #medicare logic forst row sets default
    df.loc[(df["raw_pay_type"]=="MEDICARE"),"pay_type"] = "MEDICARE ADVANTAGE"
    df.loc[(df["payer_name"].str.startswith("MEDICARE FFS", na=False)) & (df["raw_pay_type"]=="MEDICARE"),"pay_type"] = "MEDICARE FFS"

    df.loc[df["payer_name"].str.contains("DOD|DEPARTMENT OF DEFENSE|TRICARE", na=False),"pay_type"] = "FEDERAL"
    df.loc[df["pay_type"]=="TRICARE","pay_type"] = "FEDERAL"

    # del df["state"]

    df = df.drop_duplicates()

    accounts = pd.read_sql("select [payer_name]      ,[pay_type]      ,[rosetta_payer_id]      ,[raw_pay_type] from rosetta_raw_hub_payer",conn)
    df = df.merge(accounts,'left',on=["payer_name","pay_type","raw_pay_type"])

    return df


# for  importing raw sources into raw tables
def build_raw_hub_table(df, pm_id=False):
    #first 
    
    if pm_id:
        df["insurance_type"] = df["insurance_type"].str.lower()
        df = df.copy().dropna(subset=["pm_id","payer_name","pay_type","insurance_type"])
    else:
        df = df[df["pay_type"].notnull()]
        for item in ["pm_id","insurance_type","hub_pbm","product"]:
            try:
                del df[item]
            except:
                pass
        df = df.copy().dropna(subset=["payer_name","pay_type"])

    df["pay_type"] = df["pay_type"].str.upper()
    df["payer_name"] = df['payer_name'].str.upper()

    df.loc[(df["pay_type"]=="MEDICARE") & ((df["state"].notna())),"payer_name"] = df["payer_name"] + " " + df["state"]
    df["raw_pay_type"] = df["pay_type"]

    #medicaid logic first row sets default
    df.loc[df["raw_pay_type"]=="MEDICAID","pay_type"] = "MANAGED MEDICAID"

    for x in ['STATE OF', 'DISTRICT OF COLUMBIA', 'TERRITORY OF PUERTO RICO', 'TERRITORY OF VIRGIN ISLANDS']:
        df.loc[df["payer_name"].str.contains(x, na=False),"pay_type"] = "FFS MEDICAID"

    df.loc[df["pay_type"].str.contains("Medicaid Unspecified", na=False),"pay_type"] = "FFS MEDICAID"
    df.loc[(df["payer_name"].isna()) & (df["raw_pay_type"]=="MEDICAID"),"pay_type"] = "FFS MEDICAID"

    #medicare logic forst row sets default
    df.loc[(df["raw_pay_type"]=="MEDICARE"),"pay_type"] = "MEDICARE ADVANTAGE"
    df.loc[(df["payer_name"].str.startswith("MEDICARE FFS", na=False)) & (df["raw_pay_type"]=="MEDICARE"),"pay_type"] = "MEDICARE FFS"

    df.loc[df["payer_name"].str.contains("DOD|DEPARTMENT OF DEFENSE|TRICARE", na=False),"pay_type"] = "FEDERAL"
    df.loc[df["pay_type"]=="TRICARE","pay_type"] = "FEDERAL"
    df.loc[df["payer_name"]=="FEDERAL EMPLOYEE PROGRAM","pay_type"] = "COMMERCIAL"

    del df["state"]

    df = df.drop_duplicates()

    df["rosetta_payer_id"] = None
    df["date_added"] = datetime.now()
    return df

def update_hub_value(payer_name, raw_pay_type, table_name, field, value):
    query = """
        update {0} 
        set {1} = ?
        where payer_name = ? 
        and raw_pay_type = ?
        
    """.format(table_name, field)
    vals = (value, payer_name, raw_pay_type, source)
    cursor.execute(query,vals)
    cursor.commit()

    return 0

def update_values_hub(df, table_name, no_compare=["record_id", "source_id"]):
    compare_cols = list(df.columns)

    for col in no_compare:
        compare_cols.remove(col)

    current_df = pd.read_sql("select * from {0} where source = '{1}'".format(table_name,source), con=conn)

    df = df.merge(current_df,"left",["payer_name","raw_pay_type"], suffixes=("","_old"))
    log_df = pd.DataFrame(columns=["payer_name","raw_pay_type","field","new_value","old_value"])
    
    for col in compare_cols:
        df.loc[df[col] != df[col+'_old'],"update_" + col] = 1
        append_df = df[df["update_"+col] ==1][["payer_name","raw_pay_type", col+'_old', col]].rename(columns={col:"new_value",col+"_old":"old_value"})
        # append_df = df[df["update_"+col] ==1][["source_id",col]].rename(columns={col:"value"})
        append_df["field"] = col
        log_df = pd.concat([log_df,append_df])


    log_df["change_date"] = datetime.now()
    
    log_df["table"] = table_name
    for iter, row in log_df.iterrows():
        update_hub_value(row["payer_name"], row["raw_pay_type"], table_name, row["field"], row["new_value"])
        
    # write_sql(log_df,"rosetta_log_changes", if_exists="append")
    return log_df

def update_values(df, table_name):
    compare_cols = list(df.columns)

    for col in ["record_id", 'source', "source_id",'date_added']:
        compare_cols.remove(col)

    source = df.iloc[0]["source"]
    current_df = pd.read_sql("select * from {0} where source = '{1}'".format(table_name,source), con=conn)

    df = df.merge(current_df,"left","source_id", suffixes=("","_old"))
    log_df = pd.DataFrame(columns=["source_id","field","new_value","old_value"])
    
    for col in compare_cols:
        df.loc[df[col] != df[col+'_old'],"update_" + col] = 1
        append_df = df[df["update_"+col] ==1][["source_id", col+'_old', col]].rename(columns={col:"new_value",col+"_old":"old_value"})
        # append_df = df[df["update_"+col] ==1][["source_id",col]].rename(columns={col:"value"})
        append_df["field"] = col
        log_df = pd.concat([log_df,append_df])


    log_df["change_date"] = datetime.now()
    log_df["source"] = source
    log_df["table"] = table_name
    for iter, row in log_df.iterrows():
        update_value(source, row["source_id"], table_name, row["field"], row["new_value"])
        
    write_sql(log_df,"rosetta_log_changes", if_exists="append")
    return log_df

def add_hub_ids():
    df = pd.read_sql("select * from rosetta_raw_hub_payer",conn)
    max_v = pd.read_sql("select rosetta_payer_id from rosetta_raw_hub_payer where rosetta_payer_id is not null",conn)
    try:
        max_hub = int(max_v[["rosetta_payer_id"]].dropna().sort_values(by="rosetta_payer_id",ascending=False).iloc[0].item()[-6:])+1
        print(max_hub)
    except Exception as e:
        print(e)
        max_hub = 0
    new = df[df["rosetta_payer_id"].isnull()]
    print(len(new))
    for it, row in new.iterrows():
        try:
            update_hub_id("R-"+str(max_hub).zfill(6), row["payer_name"], row["pay_type"], row["raw_pay_type"])
            max_hub += 1
        except Exception as e:
            print(e)
            pass

def log_change(source_id,source,field,new_value,old_value,username,table):
    df = pd.DataFrame(data=[{"user_name":username,"source_id":source_id,"source":source,"field":field,"new_value":new_value,"old_value":old_value,"table":table,"change_date":datetime.now()}])
    write_sql(df,"rosetta_log_changes", if_exists="append")

def update_hub_id(rosetta_payer_id, payer_name, pay_type, raw_pay_type):
    print(rosetta_payer_id)
    query = """
        update rosetta_raw_hub_payer 
        set rosetta_payer_id = ?
        where payer_name = ?
        and pay_type = ?
        and raw_pay_type = ?
    """

    vals = (rosetta_payer_id, payer_name, pay_type, raw_pay_type)
    cursor.execute(query, vals)
    cursor.commit()
    return 0

def pad_id(id,source,table="rosetta_source_payer"):
    if source=="historical" and table=="rosetta_source_payer":
        return("H0000000" + str(id))
    elif source =="manual-override" and table=="rosetta_source_payer":
        return("M-" + str(id).zfill(z_fill))
    elif source == "precision" and table=="rosetta_source_payer":
        return(str(id).zfill(z_fill))
    elif source == "precision" and table=="rosetta_source_enterprise":
        return("E-" + str(id).zfill(z_fill))
    elif (source == "manual" or source=="historical") and table=="rosetta_source_enterprise":
        return("ME-" + str(id).zfill(z_fill))
    elif source == "precision" and table=="rosetta_source_pbm":
        return("PBM-" + str(id).zfill(z_fill))
    
def delete_manual(source_id,source,table):
    cursor.execute("delete from {0} where source_id = ? and source = ?".format(table),(source_id,source))
    cursor.commit()
    return 

def create_manual(record_id,source,payer,payer_type,table):
    if source=="historical":
        df = pd.read_sql("select source_id from {0} where source = '{1}'".format(table,source),conn)
        try:
            max_hub = int(df[["source_id"]].dropna()["source_id"].str[1:].astype(int).max())+1
        except Exception as e:
            print(e)
            max_hub = 1
        
    else:
        df = pd.read_sql("select source_id from {0} where source = '{1}'".format(table,source),conn)
        try:
            max_hub = int(df[["source_id"]].dropna().sort_values(by="source_id",ascending=False).iloc[0].item()[-6:])+1
        except Exception as e:
            print(e)
            max_hub = 1
    print(pad_id(max_hub+1,source))
    if "payer" in table:
        cursor.execute("insert into {0} (record_id,source,source_id,payer,payer_type,rosetta_payer_index,date_added) values(?,?,?,?,?,?,?)".format(table),(record_id,source,pad_id(max_hub,source),payer,payer_type,payer+payer_type,datetime.now()))
        cursor.commit()
        return 
def new_source(source_name,source_query,hier,enabled,data_type,table_name):
    df = pd.DataFrame(data=[{"source_name":source_name,
                        "source_query":source_query,
                        "write_table":table_name,
                        "hierarchy":hier,
                        "enabled":enabled,
                        "data_type":data_type,
                        "date_source_added":datetime.now()}])
    df["source_id"] = pd.read_sql("select max(source_id) from rosetta_config_sources",con=conn).iloc[0].item()+1
    write_sql(df,"rosetta_config_sources",if_exists="append")
    return df

def prepare_source(df, source):
    df["record_id"] = None
    df["source"] = source
    
    if "payer_type" in list(df.columns):
        df["payer_type"] = df["payer_type"].str.upper()
    df["source_id"] = df["source_id"].str.strip()
    df["date_added"] = datetime.now()
    cols = list(df.columns)

    first_cols = ["record_id","source"]

    for x in first_cols:
        cols.remove(x)
    
    return df[first_cols + cols]

def write_sql(df, name, if_exists="append"):

    query = """
    SELECT TABLE_NAME
    FROM INFORMATION_SCHEMA.TABLES
    WHERE TABLE_TYPE = 'BASE TABLE' AND TABLE_CATALOG='Rosetta'
    """
    tables = list(pd.read_sql(query,con=conn)["TABLE_NAME"])

    if name in tables:
        cols = pd.read_sql("select top(1) * from {0}".format(name),con=conn)

        for col in df.columns:
            if col not in cols:
                cursor.execute("ALTER TABLE {0} ADD {1} varchar(255)".format(name,col))
                cursor.commit()
    df.to_sql(name=name, if_exists=if_exists, index=False, con=conn)

def update_id(record_id, source_id, source, table_name):

    query = """
        update {0} 
        set record_id = ?
        where source = ? 
        and source_id = ?
    """.format(table_name)
    vals = (record_id, source, source_id)
    print(vals)
    cursor.execute(query,vals)
    cursor.commit()
    return 0

def update_value(source, source_id, table_name, field, value):
    query = """
        update {0} 
        set {1} = ?
        where source = ? 
        and source_id = ?
    """.format(table_name, field)
    vals = (value, source, source_id)
    cursor.execute(query,vals)
    cursor.commit()

    return 0

def get_new_record_id(table_name):
    query = """
    select max(record_id) as max_id from {0}
    """.format(table_name)

    max_int = int(pd.read_sql(query, conn).iloc[0]["max_id"])
    max_int += 1
    return str(max_int).zfill(z_fill)

def add_to_prod(source_table_name,prod_table_name,record_id):
    df = pd.read_sql("select * from {0} where record_id = '{1}'".format(source_table_name,record_id),con=conn)

    hier = pd.read_sql("select * from rosetta_config_sources where write_table = '{0}'".format(source_table_name),conn)[["source_name","hierarchy"]].rename(columns={"source_name":"source"})

    precision = df.query("source == 'precision'")[["record_id","source_id"]].rename(columns={"source_id":"precision_id"})

    if len(precision)==1:
        precision_id = precision["precision_id"].values[0]
    else:
        precision_id = ""

    df = df.merge(hier,"left","source")

    group = df.groupby(["record_id"]).agg({"hierarchy":min}).reset_index()
    # display(group)

    if source_table_name == "rosetta_source_payer":
        out = df.merge(group,"inner",["record_id","hierarchy"])[["record_id","payer","payer_type","raw_payer_type","rosetta_payer_index","source"]]



        query = """declare @record_id varchar(max) = '{0}'
                declare @payer varchar(max) = '{1}'
                declare @payer_type varchar(max) ='{2}'
                declare @rosetta_payer_index varchar(max) = '{3}'
                declare @source varchar(max) = '{4}'
                declare @precision_id varchar(max) = '{5}'

                BEGIN TRANSACTION;
                
                UPDATE [rosetta_prod_payer] WITH (UPDLOCK, SERIALIZABLE) SET payer = @payer, payer_type=@payer_type, rosetta_payer_index=@rosetta_payer_index, [source]=@source,precision_id=@precision_id WHERE record_id = @record_id;
                
                IF @@ROWCOUNT = 0
                BEGIN
                INSERT [rosetta_prod_payer](record_id, payer, payer_type, rosetta_payer_index, [source], precision_id) VALUES(@record_id, @payer, @payer_type, @rosetta_payer_index, @source, @precision_id);
                END
                
                COMMIT TRANSACTION;""".format(record_id, out["payer"].values[0], out["payer_type"].values[0], out["rosetta_payer_index"].values[0], out["source"].values[0], precision_id)
        cursor.execute(query)
        cursor.commit()
      
    else:
        out = df.merge(group,"inner",["record_id","hierarchy"])
    try:
        out = out.merge(precision,"left","record_id")
    except:
        pass
    # display(out)

    # write_sql(out,prod_table_name,if_exists='append')

def source_to_prod(source_table_name,prod_table_name):
    df = pd.read_sql("select * from {0}".format(source_table_name),con=conn)

    hier = pd.read_sql("select * from rosetta_config_sources where write_table = '{0}'".format(source_table_name),conn)[["source_name","hierarchy"]].rename(columns={"source_name":"source"})

    precision = df.query("source == 'precision'")[["record_id","source_id"]].rename(columns={"source_id":"precision_id"})

    df = df.merge(hier,"left","source")

    group = df.groupby(["record_id"]).agg({"hierarchy":min}).reset_index()
    # display(group)

    if source_table_name == "rosetta_source_payer":
        out = df.merge(group,"inner",["record_id","hierarchy"])[["record_id","payer","payer_type","raw_payer_type","rosetta_payer_index","source"]]
    elif source_table_name == "rosetta_source_pbm":
        out = df.merge(group,"inner",["record_id","hierarchy"])[["record_id","pbm_vendor","source"]]
    else:
        out = df.merge(group,"inner",["record_id","hierarchy"])[["record_id","enterprise","source"]]

    out = out[~out.duplicated(["record_id"])]

    out = out.merge(precision,"left","record_id")
    # display(out)
    write_sql(out,prod_table_name,if_exists='replace')

def add_new_ids(source_name, table_name):
    df = pd.read_sql("select * from {0} where source = '{1}'".format(table_name,source_name),conn)

    query = """
    select max(record_id) as max_id from {0}
    """.format(table_name)

    max_int = pd.read_sql(query, conn).iloc[0]["max_id"]
    # if type(None) == type(max_int) or max_int == None:
    #     max_int = 0
    # else:
    #     max_int = int(max_int)
    try:
        max_int = int(max_int)
    except:
        max_int = 0
    


    df = df[df["record_id"].isna()]

    for it, row in tqdm(df.iterrows()):
        max_int += 1
        update_id(str(max_int).zfill(z_fill), row["source"], row["source_id"], table_name)        

def match_new_record():

    return 0
def get_new_existing_accounts(df, source, table_name):

    # quarentiene for tables

    current_df = pd.read_sql("select source, source_id from {0} where source = '{1}'".format(table_name,source),conn)
    new_accounts = left_anti(df,current_df,["source","source_id"])
    old_accounts = left_anti(df,new_accounts,["source","source_id"])
    return {"new_accounts":new_accounts,"old_accounts":old_accounts}


def log_run(df,source,start_time):
    stop_time = hf.long_date()
    try:
        run_id = int(pd.read_sql("select max(run_id) as run_id from rosetta_log_run",conn).iloc[0]["run_id"]) + 1
    except:
        run_id = 1
    new_row = pd.DataFrame(data=[{"run_id":run_id,
                                    "number_new_accounts":len(df),
                                    "time_start":start_time,
                                    "time_end":stop_time,
                                    "source":source}])
    write_sql(new_row,'rosetta_log_run')


def create_view():
    query = """ALTER VIEW rosetta_master AS
    select payer.*
	,enter.enterprise
	,enter.record_id as enterprise_id
	,enter.source as enterprise_source
	,hier.precision_enterprise_id
	,pbm.pbm_vendor
	,pbm.record_id as pbm_id
	,pbm.source as pbm_source
	,hier.precision_pbm_id
	
  FROM [Rosetta].[dbo].[rosetta_prod_payer] as payer 
  full outer join [Rosetta].[dbo].rosetta_hierarchy as hier on payer.record_id=hier.payer_id
  full outer join [rosetta_prod_enterprise] as enter on enter.record_id=hier.[enterprise_id]
  full outer join [rosetta_prod_pbm] as pbm on pbm.record_id=hier.pbm_id"""
    cursor.execute(query)
    cursor.commit()

v = """alter view rosetta_quarantine as SELECT *
  FROM [Rosetta].[dbo].[rosetta_potential_matches] where record_id_matched is not null and (account_name = payer and source_new<>source_matched)and record_id_new is null"""

view="""alter view rosetta_bridge as SELECT  b.[pm_id]
      ,b.[rosetta_payer_id]
      ,b.product
      ,b.insurance_type
	  ,p.[record_id]
      ,case when p.[payer] is not null then p.payer else s.payer end as payer
      ,case when p.[payer_type] is not null then p.payer_type else s.payer_type end as payer_type
      ,case when p.[rosetta_payer_index] is not null then p.[rosetta_payer_index] else s.[rosetta_payer_index] end as rosetta_payer_index
	  ,case when m.source is not null then m.source else 'quarantine' end as payer_source
      ,p.[precision_id]
	  ,m.enterprise
	  ,m.enterprise_id
	  ,m.enterprise_source
	  ,m.pbm_vendor
	  ,m.pbm_id
  FROM [Rosetta].[dbo].[rosetta_bridge_hub_pat] as b 
  left join rosetta_master as m on p.record_id=m.record_id
  full outer join rosetta_source_payer as s on b.rosetta_payer_id=s.source_id 
  full outer join rosetta_prod_payer as p on s.record_id = p.record_id
  where b.pm_id is not null"""

def process_source_table(source, table_name):

    query = """
        select * from {0}
    """.format(table_name)
    

    df = pd.read_sql(query,conn)

    accounts = df[df["record_id"].notna()]
    display(accounts)
    new_accounts = df[(df["source"] == source) &
                     (df["record_id"].isna())]
    add_new_ids(new_accounts, table_name)

    return 0    


# matching for quarantine 

def awesome_cossim_top(A, B, ntop, lower_bound=0):
    # force A and B as a CSR matrix.
    # If they have already been CSR, there is no overhead
    A = A.tocsr()
    B = B.tocsr()
    M, _ = A.shape
    _, N = B.shape
 
    idx_dtype = np.int32
 
    nnz_max = M*ntop
 
    indptr = np.zeros(M+1, dtype=idx_dtype)
    indices = np.zeros(nnz_max, dtype=idx_dtype)
    data = np.zeros(nnz_max, dtype=A.dtype)

    ct.sparse_dot_topn(
        M, N, np.asarray(A.indptr, dtype=idx_dtype),
        np.asarray(A.indices, dtype=idx_dtype),
        A.data,
        np.asarray(B.indptr, dtype=idx_dtype),
        np.asarray(B.indices, dtype=idx_dtype),
        B.data,
        ntop,
        lower_bound,
        indptr, indices, data)

    return csr_matrix((data,indices,indptr),shape=(M,N))

def get_matches_df(sparse_matrix, name_vector, top=False):
    non_zeros = sparse_matrix.nonzero()
    
    sparserows = non_zeros[0]
    sparsecols = non_zeros[1]
    
    if top:
        nr_matches = top
    else:
        nr_matches = sparsecols.size
    
    left_side = np.empty([nr_matches], dtype=object)
    right_side = np.empty([nr_matches], dtype=object)
    similarity = np.zeros(nr_matches)
       
    for index in range(0, nr_matches):
        try:
            left_side[index] = name_vector[sparserows[index]]
            right_side[index] = name_vector[sparsecols[index]]
            similarity[index] = sparse_matrix.data[index]
        except:
            break
    ret = pd.DataFrame({'left_side': left_side,
                          'right_side': right_side,
                           'similarity': similarity})

    ret = ret[ret["left_side"].notnull()]
    ret = ret[ret["right_side"].notnull()]
    return ret

class similar_accounts:
    """
    matches similar accounts. 
    will capitalize account names 
    
    
    """

    def __init__(self,table_name):
        self.table = pd.read_sql("select * from {0} ".format(table_name),conn)
        df = pd.read_sql("select * from {0} ".format(table_name),conn)
        self.table["payer"] = self.table["payer"].str.upper()
        df["payer"] = df["payer"].str.upper()
        vectorizer = TfidfVectorizer(min_df=1, analyzer=ngrams)

        names = list(set(list(df.astype(str)["payer"].drop_duplicates())))

        tf_idf_matrix = vectorizer.fit_transform(names)
        matches = awesome_cossim_top(tf_idf_matrix, tf_idf_matrix.transpose(), 1000, 0.50)
        matches_df = get_matches_df(matches, names)
        matches_df = matches_df[matches_df["similarity"]>=.50]
        
        matches_df.columns = ["account_name","payer","similarity"]
        self.match_table = matches_df

    def get_similar_accounts(self, acct_name):
        return self.match_table[self.match_table["account_name"]==acct_name].merge(self.table,"left","payer")
    
    def save_table(self):
        df = pd.read_sql("select * from rosetta_log_quarantine",conn)
        df = self.table.merge(df[["source_id","source"]],"inner",["source_id","source"])
        write_sql(self.match_table.merge(df.rename(columns={"payer":"account_name"}),"inner","account_name").merge(self.table,"outer","payer",suffixes=("_new","_matched")),"rosetta_potential_matches",if_exists="replace")


krystexxa_payer_query = """  
                        SELECT DISTINCT p.Patient_ID_2 AS 'pm_id',
                                          'KRYSTEXXA' as 'product',
						case when p.primary_payer is not null then p.primary_payer
						when p.primary_plan_name is not null then p.primary_plan_name 
						when p.Secondary_Payer is not null then p.Secondary_Payer
						when p.Secondary_Plan_Name is not null then p.Secondary_Plan_Name end as 'payer_name',                   
                        p.Primary_PAM_Payer_Type as 'pay_type',
                        'primary' as insurance_type,
                        p.Enrolling_HCP_State AS 'state'
                        ,p.PBM_Name as hub_pbm,
						p.Enrollment_Date as enroll_date
                        FROM USLSACASQL1.KRYSTEXXA.dbo.tbl_PAM_Hub_Data AS p 
                        """

tepezza_payer_query = """SELECT info.[pm_id]
, 'TEPEZZA' as 'product'
,info.[payer_name]
,info.[pay_type]
,'primary' as insurance_type
,addr.[state] 
,info.pbm_name as hub_pbm
,p.[enrollment_date] as enroll_date

FROM USLSACASQL2.[Tepro_Veeva].[dbo].[vw_PM_payer_info] as info 
left join USLSACASQL2.[Tepro_Veeva].[dbo].[vw_PM_contact_info_address] as addr on info.pm_id = addr.pm_id 
left join USLSACASQL2.[Tepro].[dbo].[tep_patient] as p on p.patient_id=info.pm_id"""

rdbu_query = """With new as (/*Extracting patients with active payer/insurance, without null*/
            select Program_Member_MVN__c,
                   HZN_Insurance_Type__c, 
	               max(Policy_Effective_Date_MVN__c) as policy_date
            from USLSACASQL2.orp_veeva.dbo.veeva_ib_benefits_coverage
            where Status_MVN__c='Active' and 
                  HZN_Program_Name__c IN ('RAVICTI', 'ACTIMMUNE' ,'PROCYSBI', 'BUPHENYL') and 
	              HZN_Insurance_Type__c is not null
            group by Program_Member_MVN__c,HZN_Insurance_Type__c
			),
new1 as (/*Extracting patients without active payer/insurance*/
        select Program_Member_MVN__c,
               HZN_Insurance_Type__c, 
	           max(Policy_Effective_Date_MVN__c) as policy_date
        from USLSACASQL2.orp_veeva.dbo.veeva_ib_benefits_coverage
        where Status_MVN__c='Active' and 
              HZN_Program_Name__c IN ('RAVICTI', 'ACTIMMUNE' ,'PROCYSBI', 'BUPHENYL') and 
	          HZN_Insurance_Type__c is null and 
              Program_Member_MVN__c NOT in (select Program_Member_MVN__c
                                            from USLSACASQL2.orp_veeva.dbo.veeva_ib_benefits_coverage
                                            where Status_MVN__c='Active' and 
									              HZN_Program_Name__c IN ('RAVICTI', 'ACTIMMUNE' ,'PROCYSBI', 'BUPHENYL') and 
										          HZN_Insurance_Type__c is  not null
                                             group by Program_Member_MVN__c
											 )
       group by Program_Member_MVN__c,HZN_Insurance_Type__c
	   ),
combined as ( /*Combing two data sets, to have a universe*/
             select Program_Member_MVN__c,
			        HZN_Insurance_Type__c,
					policy_date
              from new 
        union
             select Program_Member_MVN__c,
			        HZN_Insurance_Type__c,
					policy_date
              from new1
			 ),
new3 as (/*Extracting payer & PBM info from B&C table*/
         select distinct bc.Program_Member_MVN__c,
                         bc.HZN_Payer_Account_Name__c,
	                     bc.HZN_KRY_Payer_Name__c,
	                     bc.Plan_Name_MVN__c,
	                     bc.PBM_Name_MVN__c,
	                     bc.HZN_Plan_Coverage_Type__c,
                         bc.Policy_Expiration_Date_MVN__c,
	                     bc.Policy_Effective_Date_MVN__c,
	                     bc.Status_MVN__c,
	                     bc.HZN_Insurance_Type__c
	      from USLSACASQL2.orp_veeva.dbo.veeva_ib_benefits_coverage as bc
	      where Status_MVN__c='Active' and 
	            HZN_Program_Name__c IN ('RAVICTI', 'ACTIMMUNE' ,'PROCYSBI', 'BUPHENYL')
		 ),
new4 as (/*Joining universe with extracted fields from b&c table*/
         select a.*,
                b.HZN_Payer_Account_Name__c,
                b.HZN_KRY_Payer_Name__c,
                b.Plan_Name_MVN__c,
                b.PBM_Name_MVN__c,
                b.Policy_Expiration_Date_MVN__c,
                b.HZN_Plan_Coverage_Type__c
          from combined as a 
          left join 
               new3 as b
          on a.Program_Member_MVN__c=b.Program_Member_MVN__c and 
            (a.policy_date=b.Policy_Effective_Date_MVN__c or (a.policy_date is null and b.Policy_Effective_Date_MVN__c is null)) and 
            (a.HZN_Insurance_Type__c=b.HZN_Insurance_Type__c or (a.HZN_Insurance_Type__c is null and b.HZN_Insurance_Type__c is null))
		),
new5 as (/*Pulling Therapy status & PM id from ib program member table*/
        select distinct id, 
                        name,
				        HZN_Current_Therapy__c,
				        Enrollment_Date_MVN__c,
	                    Program_Name_MVN__c, 
	                    Horizon_Status_MVN__c
         from USLSACASQL2.orp_veeva.dbo.veeva_ib_program_member
		 ),
new6 as (/*joining universe table with ib program member table*/
         select a.*, 
                b.name,
				b.HZN_Current_Therapy__c,
				b.Enrollment_Date_MVN__c,
	            b.Program_Name_MVN__c, 
	            b.Horizon_Status_MVN__c
          from new4 as a 
		  left join 
		       new5 as b
          on a.Program_Member_MVN__c=b.Id
		  ),
new7 as (/*Creating a row number column to see how many patients have multiple insurance type*/
         select *,
               ROW_NUMBER()  OVER(PARTITION BY Name, HZN_Insurance_Type__c ORDER BY Name) as  plan_rank 
         from new6
		 ),
new8 as (/*Extracting most recent status events for patients to know if they are on time, late, or DC */
         select a.*,
		        b.pm_id
         from
             (select a.*,
			         b.status_type
              from 
                  (select patient_id, 
				          max(start) as recent_start_date
                   FROM USLSACASQL2.orp.dbo.orp_statuses
                   where status='refill_status'
                   group by patient_id 
				   ) as a
              left join
                   (select distinct patient_id,
				                    status_type,
									start
                    from USLSACASQL2.orp.dbo.orp_statuses
                    where status='refill_status'
                    group by patient_id,status_type,start
					) as b
               on a.patient_id=b.patient_id and 
			      a.recent_start_date=b.start
				) as a 
          left join
                (select distinct pm_id,
				                 patient_id 
				 from USLSACASQL2.orp.dbo.orp_patient
				 ) as b
           on a.patient_id=b.patient_id),

new9 as (
         select a.*,
		        b.status_type
          from new7 as a 
		  left join 
		        new8 as b
          on a.Name=b.pm_id
		  )
select 
[name] as pm_id,HZN_Current_Therapy__c as 'product',HZN_Payer_Account_Name__c as payer_name,
        HZN_Plan_Coverage_Type__c as pay_type,
        HZN_Insurance_Type__c as insurance_type,
        '' as state
        ,PBM_Name_MVN__c as hub_pbm 
		from new9 where HZN_Insurance_Type__c is not null and HZN_Current_Therapy__c='{0}';
"""

ravicti_payer_query = rdbu_query.format("RAVICTI")
actimmune_payer_query = rdbu_query.format("ACTIMMUNE")
procysbi_payer_query = rdbu_query.format("PROCYSBI")
buphenyl_payer_query = rdbu_query.format("BUPHENYL")

uplizna_payer_query = """
        SELECT info.[pm_id]
, 'UPLIZNA' as 'product'
,info.[payer_name]
,info.[pay_type]
,'primary' as insurance_type
,addr.[state] 
,info.pbm_name as hub_pbm
,pm.Enrollment_Date_MVN__c as enroll_date
FROM USLSACASQL2.[UPLIZNA_Veeva].[dbo].[vw_PM_payer_info_primary] as info 
left join USLSACASQL2.[UPLIZNA_Veeva].[dbo].[vw_PM_contact_info_address] as addr on info.pm_id = addr.pm_id
left join USLSACASQL2.UPLIZNA_Veeva.[dbo].[qral_ob_program_members] as pm on info.pm_id=pm.[Name]
"""

queries =  {"krystexxa":krystexxa_payer_query,
            "tepezza":tepezza_payer_query,
            "uplizna":uplizna_payer_query,
            "ravicti":ravicti_payer_query,
            "actimmune":actimmune_payer_query,
            "procysbi":procysbi_payer_query,
            "buphenyl":buphenyl_payer_query}
