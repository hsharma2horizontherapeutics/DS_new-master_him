from ds.helper_functions import connect
import pandas as pd

db="Rosetta"
server="USLSACASQL1"

conn = connect(server=server,db=db,engine=True)

query = """/****** Script for SelectTopNRows command from SSMS  ******/
SELECT TOP (1000) [payer_entity_id]
      ,[payer_entity]
      ,[bob_id]
      ,[bob]
      ,[enterprise_id]
      ,[enterprise]
      ,[pop_desc]
      ,[formulary_desc]
      ,[payer_plan_detail]
      ,[sub_pop_desc]
      ,[pbm_vendor_id]
      ,[pbm_vendor]
      ,[relationship_type]
      ,[formulary_id]
      ,[formulary_name]
      ,[delivery_dt]
  FROM [Rosetta].[dbo].[Payer_Plan_Hierarchy]"""

print(pd.read_sql(query,conn))

df = pd.read_sql(query,conn)

def match_payers():
    return 0 

def quarantine_log(df):
    df.to_sql(name="payer_quarantine_log")
    return 0 


# df.to_sql(name="source_payer_log",con=conn, if_exists="append")
# df.to_sql(name="prod_payer",con=conn, if_exists="append")