from ds.helper_functions import connect, left_anti
import ds.helper_functions as hf
import pandas as pd
import numpy as np
from tqdm import tqdm
from datetime import datetime, timedelta
import functions as rf
import os 
from datetime import date

root_path = os.path.dirname(os.path.abspath(__file__))

z_fill = rf.z_fill
ds_conn = rf.ds_conn
conn = rf.conn
cursor = rf.cursor
sources = pd.read_sql("select * from rosetta_config_sources",conn)



def run():
    queries =  rf.queries
    for key in queries:
        start_time = datetime.now()
        print(key)
        df = pd.read_sql(queries[key],conn)
        df = rf.build_raw_hub_table(df)
        existing = pd.read_sql("select * from rosetta_raw_hub_payer",conn)
        new = left_anti(df,existing,["payer_name","pay_type","raw_pay_type"]).dropna(subset=['payer_name',"pay_type",'raw_pay_type']).query("payer_name != 'nan'")
        # rf.update_values_hub(old,"rosetta_raw_hub_payer",no_compare=["payer_name","raw_pay_type","rosetta_payer_id"])
        rf.write_sql(new,"rosetta_raw_hub_payer",if_exists="append")
        rf.add_hub_ids()
        rf.log_run(new,key+"_hub",start_time)


    full_bridge = pd.concat([pd.read_sql(rf.queries[prod],conn) for prod in rf.queries]).reset_index(drop=True)
    pat_df = rf.build_raw_hub_table(full_bridge, pm_id=True)
    del pat_df["rosetta_payer_id"]
    raw_source = pd.read_sql("select * from rosetta_raw_hub_payer",conn)[["rosetta_payer_id","payer_name","pay_type","raw_pay_type"]]
    full_bridge = pat_df.merge(raw_source,"left",on=["payer_name","pay_type","raw_pay_type"])[["pm_id","product","rosetta_payer_id","insurance_type","hub_pbm"]]

    rf.write_sql(full_bridge,"rosetta_bridge_hub_pat",if_exists="replace")

    for row in [12]:
        start_time = hf.long_date()
        payer = pd.read_sql(sources.iloc[row]["source_query"],con=conn)
        payer = payer.drop_duplicates(subset=['source_id'])
        source = sources.iloc[row]["source_name"]
        write_table = sources.iloc[row]["write_table"]

        payer = rf.prepare_source(payer, source)
        new_old = rf.get_new_existing_accounts(payer, source, write_table)

        if len(new_old["new_accounts"])>0:

            new_old["new_accounts"]["date_added"] = datetime.now()

            rf.write_sql(new_old["new_accounts"], write_table, if_exists="append")
            if source != "precision" or source != "historical":

                rf.write_sql(new_old["new_accounts"],"rosetta_log_quarantine")

        if len(new_old["old_accounts"])>0:
            rf.update_values(new_old["old_accounts"], write_table)
        #   check if existisng accounts changed

        rf.log_run(new_old["new_accounts"],source+"_raw_to_payer",start_time)

    print("run_done")

def bridge_history():
    df = pd.read_sql("SELECT * from rosetta_bridge_hub_pat",rf.conn)
    df["month_id"] = str(datetime.now().year) + str(datetime.now().month).zfill(2)
    df["date_saved"] = datetime.now()
    rf.write_sql(df,"rosetta_bridge_history_hub_pat")
    
def send_extract(emails):
    bridge = pd.read_sql("select * from rosetta.dbo.rosetta_bridge",conn).fillna("")
    mast = pd.read_sql("select * from [Rosetta].[dbo].[rosetta_master]",conn).fillna("")
    quar = pd.read_sql("select * from [Rosetta].[dbo].[rosetta_log_quarantine]",conn).fillna("")
    src = pd.read_sql("select * from [Rosetta].[dbo].[rosetta_source_payer] where record_id is not null",conn).fillna("")

    file_name = os.path.join(root_path, 'extracts', hf.short_date() + '_rosetta_extract.xlsx')
    writer = pd.ExcelWriter(file_name, engine='xlsxwriter')

    quar.to_excel(writer, sheet_name='Quarantine', index=False)
    src.to_excel(writer, sheet_name='Source', index=False)
    mast.to_excel(writer, sheet_name='Master', index=False)
    bridge.to_excel(writer, sheet_name='Bridge', index=False)
    
    writer.save()

    number_new_accounts = pd.read_sql("SELECT sum([number_new_accounts]) as new FROM [Rosetta].[dbo].[rosetta_log_run] where source = 'allcare_hub_raw_to_payer' and time_start > DateAdd(DD,-7,CAST( GETDATE() AS Date ))",conn)["new"][0]

    message = """
    Hi Everyone, 
    <br>
    In the last week we have added {0} payer records to Rosetta
    <br> 
    The following sheets are included 
    <br>
    -	Quarantine: Records still in quarantine
    <br>
    -	Source: List of all records. No quarantine records. It is the extract of rosetta_source_payer
    <br>
    -	Master: List of Payers. It’s the list of individual mastered payers. Is built from rosetta_source_payer, but each record_id will only be in there once
    <br>
    -	Bridge: Links patients pm_id to their record_id and shows the precision_id for those that have one. 

     """.format(number_new_accounts)

    hf.sendEmail(emails,"Weekly Rosetta Extract",message, sendFrom="djosephs@horizontherapeutics.com", attachments=[file_name], actualFrom="djosephs@horizontherapeutics.com")

# data-science-no-reply
    
if __name__=="__main__":
    today = datetime.now()
    month_id = str(datetime.now().year) + str(datetime.now().month).zfill(2)
    if today == 1 or month_id not in list(pd.read_sql("select distinct month_id from rosetta_bridge_history_hub_pat",rf.conn)["month_id"]):
        bridge_history()
    
    run()

    rf.source_to_prod("rosetta_source_payer","rosetta_prod_payer")
    rf.source_to_prod("rosetta_source_enterprise","rosetta_prod_enterprise")
    rf.source_to_prod("rosetta_source_pbm","rosetta_prod_pbm")

    rf.build_bridge()
    
    s = rf.similar_accounts("rosetta_source_payer")
    s.save_table()


    # If today is Monday (aka 0 of 6), then run the report
    if date.today().weekday() == 0:
        # send_extract(['djosephs@horizontherapeutics.com'])
        send_extract(['omuchnik@horizontherapeutics.com','sgupta@horizontherapeutics.com','ngandhi@horizontherapeutics.com','tiffany@jupiterls.com','djosephs@horizontherapeutics.com'])

